"""
workflow_generator.py
=====================
Workflow Generator: converts LLM CoT reasoning into validated,
executable JSON/YAML workflow definitions.

Responsibilities:
  - Parse LLM-generated workflow JSON
  - Validate step ordering and tool compatibility
  - Enrich with default parameters from tool registry
  - Export to JSON/YAML
  - Track execution metadata

Author: GeoSpatial LLM System
"""

import json
import uuid
import yaml
from pathlib import Path
from datetime import datetime
from typing import Optional
from loguru import logger


class WorkflowGenerator:
    """
    Generates, validates, and manages geospatial workflow definitions.

    Converts Chain-of-Thought reasoning into structured, executable
    JSON/YAML workflow specifications.
    """

    def __init__(self, tool_registry_path: str = "tool_registry.json"):
        self.tool_registry = self._load_registry(tool_registry_path)
        self.tool_map = {t["tool"]: t for t in self.tool_registry.get("tools", [])}
        logger.info(f"WorkflowGenerator initialized with {len(self.tool_map)} tools")

    def _load_registry(self, path: str) -> dict:
        try:
            with open(path) as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Could not load tool registry: {e}. Using empty registry.")
            return {"tools": [], "workflow_templates": {}}

    def create_workflow(
        self,
        query: str,
        raw_steps: list[dict],
        study_area: str = "Unknown",
        crs: str = "EPSG:4326",
        workflow_id: Optional[str] = None,
    ) -> dict:
        """
        Create a complete workflow definition from step specifications.

        Args:
            query: Original user query
            raw_steps: List of step dictionaries from LLM
            study_area: Geographic area of analysis
            crs: Recommended CRS
            workflow_id: Optional custom workflow ID

        Returns:
            Complete workflow dictionary
        """
        workflow_id = workflow_id or f"wf_{uuid.uuid4().hex[:8]}"

        # Normalize and enrich steps
        enriched_steps = []
        for i, step in enumerate(raw_steps, 1):
            enriched = self._enrich_step(step, i)
            enriched_steps.append(enriched)

        workflow = {
            "workflow_id": workflow_id,
            "version": "1.0",
            "created_at": datetime.utcnow().isoformat(),
            "query": query,
            "study_area": study_area,
            "recommended_crs": crs,
            "status": "pending",
            "steps": enriched_steps,
            "execution_log": [],
            "outputs": {},
            "statistics": {},
            "metadata": {
                "total_steps": len(enriched_steps),
                "tool_categories": self._categorize_tools(enriched_steps),
            },
        }

        logger.info(f"Created workflow '{workflow_id}' with {len(enriched_steps)} steps")
        return workflow

    def _enrich_step(self, step: dict, step_number: int) -> dict:
        """
        Enrich a step with registry metadata and default parameters.

        Args:
            step: Raw step dictionary from LLM
            step_number: Step sequence number

        Returns:
            Enriched step dictionary
        """
        tool_name = step.get("tool", "unknown")
        registry_entry = self.tool_map.get(tool_name, {})

        enriched = {
            "step_id": step.get("step_id", step_number),
            "name": step.get("name", f"Step {step_number}"),
            "tool": tool_name,
            "category": registry_entry.get("category", "unknown"),
            "description": step.get("description", registry_entry.get("description", "")),
            "inputs": step.get("inputs", {}),
            "output_layer": step.get("output_layer", f"output_{step_number}"),
            "reasoning": step.get("reasoning", ""),
            "status": "pending",
            "started_at": None,
            "completed_at": None,
            "error": None,
            "output_summary": None,
        }

        # Add default parameters from registry if not specified
        default_params = registry_entry.get("parameters", {})
        for param, default_val in default_params.items():
            if param not in enriched["inputs"] and isinstance(default_val, (str, int, float, bool)):
                enriched["inputs"].setdefault(param, default_val)

        return enriched

    def _categorize_tools(self, steps: list[dict]) -> dict:
        """Count tools by category."""
        cats = {}
        for step in steps:
            cat = step.get("category", "unknown")
            cats[cat] = cats.get(cat, 0) + 1
        return cats

    def validate(self, workflow: dict) -> tuple[bool, list[str]]:
        """
        Validate a workflow for logical correctness and tool compatibility.

        Checks:
        1. Required fields present in each step
        2. Tool names exist in registry
        3. Output layer names are unique
        4. Data flow consistency (inputs reference valid previous outputs)

        Args:
            workflow: Workflow dictionary

        Returns:
            (is_valid, list_of_issues)
        """
        issues = []
        steps = workflow.get("steps", [])

        if not steps:
            issues.append("Workflow has no steps")
            return False, issues

        output_layers = set()
        REQUIRED_FIELDS = ["step_id", "name", "tool", "output_layer"]

        for step in steps:
            sid = step.get("step_id", "?")

            # Required fields
            for field in REQUIRED_FIELDS:
                if not step.get(field):
                    issues.append(f"Step {sid}: missing '{field}'")

            # Tool exists in registry
            tool = step.get("tool", "")
            if tool and tool not in self.tool_map:
                issues.append(f"Step {sid}: unknown tool '{tool}'")

            # Duplicate output layers
            out_layer = step.get("output_layer", "")
            if out_layer in output_layers:
                issues.append(f"Step {sid}: duplicate output_layer '{out_layer}'")
            output_layers.add(out_layer)

        is_valid = len(issues) == 0
        if is_valid:
            logger.info(f"Workflow validation: PASSED ({len(steps)} steps)")
        else:
            logger.warning(f"Workflow validation: {len(issues)} issues found")

        return is_valid, issues

    def from_llm_output(
        self,
        llm_workflow: dict,
        query: str,
    ) -> dict:
        """
        Convert raw LLM-generated workflow dict to a validated workflow.

        Args:
            llm_workflow: Raw dictionary from LLM output
            query: Original user query

        Returns:
            Validated and enriched workflow dictionary
        """
        steps = llm_workflow.get("steps", [])
        study_area = llm_workflow.get("study_area", "Unknown")
        crs = llm_workflow.get("estimated_crs", "EPSG:4326")
        workflow_id = llm_workflow.get("workflow_id", None)

        workflow = self.create_workflow(
            query=query,
            raw_steps=steps,
            study_area=study_area,
            crs=crs,
            workflow_id=workflow_id,
        )

        # Copy notes if present
        if "notes" in llm_workflow:
            workflow["notes"] = llm_workflow["notes"]
        if "expected_outputs" in llm_workflow:
            workflow["expected_outputs"] = llm_workflow["expected_outputs"]

        # Validate
        is_valid, issues = self.validate(workflow)
        workflow["validation"] = {"is_valid": is_valid, "issues": issues}

        return workflow

    def to_json(self, workflow: dict, indent: int = 2) -> str:
        """Serialize workflow to JSON string."""
        return json.dumps(workflow, indent=indent, default=str)

    def to_yaml(self, workflow: dict) -> str:
        """Serialize workflow to YAML string."""
        # Convert datetime objects to strings for YAML
        clean = json.loads(self.to_json(workflow))
        return yaml.dump(clean, default_flow_style=False, allow_unicode=True)

    def save(
        self,
        workflow: dict,
        output_dir: str = "outputs",
        formats: list = ("json", "yaml"),
    ) -> dict:
        """
        Save workflow definition to files.

        Args:
            workflow: Workflow dictionary
            output_dir: Output directory
            formats: Formats to save ('json', 'yaml')

        Returns:
            Dictionary of {format: file_path}
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        wid = workflow.get("workflow_id", "workflow")
        saved = {}

        if "json" in formats:
            json_path = str(output_path / f"{wid}_workflow.json")
            with open(json_path, "w") as f:
                f.write(self.to_json(workflow))
            saved["json"] = json_path
            logger.info(f"Workflow saved as JSON: {json_path}")

        if "yaml" in formats:
            yaml_path = str(output_path / f"{wid}_workflow.yaml")
            with open(yaml_path, "w") as f:
                f.write(self.to_yaml(workflow))
            saved["yaml"] = yaml_path
            logger.info(f"Workflow saved as YAML: {yaml_path}")

        return saved

    def get_execution_summary(self, workflow: dict) -> dict:
        """
        Generate execution summary after workflow runs.

        Args:
            workflow: Executed workflow dictionary

        Returns:
            Summary statistics dictionary
        """
        steps = workflow.get("steps", [])
        completed = [s for s in steps if s.get("status") == "completed"]
        failed = [s for s in steps if s.get("status") == "error"]
        pending = [s for s in steps if s.get("status") == "pending"]

        return {
            "workflow_id": workflow.get("workflow_id"),
            "total_steps": len(steps),
            "completed": len(completed),
            "failed": len(failed),
            "pending": len(pending),
            "success_rate": f"{len(completed)/max(len(steps),1)*100:.0f}%",
            "outputs_generated": list(workflow.get("outputs", {}).keys()),
        }

    def suggest_workflow_template(self, query: str) -> Optional[list[str]]:
        """
        Suggest a predefined workflow template based on query keywords.

        Args:
            query: User query string

        Returns:
            List of tool names for the suggested template, or None
        """
        query_lower = query.lower()
        templates = self.tool_registry.get("workflow_templates", {})

        keyword_map = {
            "flood_risk": ["flood", "inundation", "waterlog", "river overflow"],
            "site_suitability": ["solar", "farm", "suitable", "suitability", "site selection"],
            "land_cover": ["ndvi", "vegetation", "land cover", "forest", "green"],
            "accessibility": ["distance", "accessibility", "proximity", "reach"],
        }

        for template_name, keywords in keyword_map.items():
            if any(kw in query_lower for kw in keywords):
                if template_name in templates:
                    logger.info(f"Suggested template: {template_name}")
                    return templates[template_name]

        return None


if __name__ == "__main__":
    # Test workflow generator
    gen = WorkflowGenerator("tool_registry.json")

    # Sample LLM output
    sample_llm_output = {
        "workflow_id": "flood_risk_001",
        "study_area": "Assam, India",
        "estimated_crs": "EPSG:32646",
        "steps": [
            {"step_id": 1, "name": "Load DEM", "tool": "load_raster",
             "inputs": {"source": "dem.tif"}, "output_layer": "dem_raw",
             "reasoning": "Load elevation data"},
            {"step_id": 2, "name": "Calculate Slope", "tool": "calculate_slope",
             "inputs": {"dem_raster": "dem_raw"}, "output_layer": "slope",
             "reasoning": "Derive slope for analysis"},
        ]
    }

    workflow = gen.from_llm_output(sample_llm_output, "Find flood risk areas")
    print("Workflow created:")
    print(json.dumps(workflow, indent=2, default=str)[:400])
    print("\nValidation:", workflow["validation"])
