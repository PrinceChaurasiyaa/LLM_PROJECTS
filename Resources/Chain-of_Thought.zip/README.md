# 🌍 Chain-of-Thought LLM System for Geospatial Workflow Generation

A production-quality system that converts **natural language queries** into **executable GIS workflows** using LLM Chain-of-Thought reasoning, FAISS RAG retrieval, and a ReAct agent loop.

---

## 📐 Architecture

```
User Query
    │
    ▼
LLM Engine (Ollama/Claude/GPT)
    │   ↕ RAG Pipeline (FAISS)
    ▼
Chain-of-Thought Reasoning
    │
    ▼
Workflow Generator (JSON/YAML)
    │
    ▼
ReAct Agent Loop
    │ → GeoPandas (vector ops: buffer, overlay, spatial join)
    │ → Rasterio  (raster ops: slope, threshold, vectorize)
    │ → OSMnx     (OpenStreetMap data loading)
    ▼
Folium Map + Downloadable GIS Outputs
```

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
# Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install requirements
pip install -r requirements.txt
```

### 2. Set Up LLM Backend

**Option A — Ollama (recommended, fully local):**
```bash
# Install Ollama: https://ollama.com
ollama pull llama3        # LLaMA 3 8B
# OR
ollama pull mistral       # Mistral 7B
ollama serve              # Start Ollama server (port 11434)
```

**Option B — Anthropic Claude API:**
```bash
export ANTHROPIC_API_KEY="your-api-key-here"
```

**Option C — OpenAI API:**
```bash
export OPENAI_API_KEY="your-api-key-here"
```

### 3. Run the Application

```bash
cd geospatial_llm
streamlit run app.py
```

Open your browser at **http://localhost:8501**

---

## 📁 Project Structure

```
geospatial_llm/
├── app.py                  # Streamlit UI (main entry point)
├── llm_engine.py           # LLM reasoning + CoT prompting
├── rag_pipeline.py         # FAISS RAG knowledge retrieval
├── workflow_generator.py   # JSON/YAML workflow creation
├── gis_tools.py            # GIS execution engine
├── agent_loop.py           # ReAct Thought→Action→Observation loop
├── dataset_loader.py       # OSM, DEM, GeoJSON/Shapefile loaders
├── visualization.py        # Folium map generation
├── tool_registry.json      # GIS tool schema definitions
├── requirements.txt        # Python dependencies
│
├── knowledge_base/         # FAISS index + GIS documentation
├── data/
│   ├── sample/             # Sample GeoJSON datasets
│   └── .cache/             # Dataset cache
└── outputs/                # Generated workflows + maps
```

---

## 💡 Example Queries

| Query | Use Case |
|-------|----------|
| `Find flood-prone areas near rivers in Assam, India` | Flood risk mapping |
| `Identify suitable locations for solar farms in Rajasthan` | Site suitability |
| `Analyze vegetation health and NDVI in forest regions` | Land cover analysis |
| `Find areas suitable for urban expansion avoiding forests` | Urban planning |
| `Identify low-lying areas prone to waterlogging near streams` | Drainage analysis |

---

## ⚙️ Module Details

### `llm_engine.py` — LLM Reasoning Engine
- Supports Ollama (LLaMA-3, Mistral), Anthropic Claude, OpenAI GPT
- CoT prompt templates for geospatial reasoning
- JSON workflow extraction from LLM output
- Workflow validation
- Mock responses for offline/demo mode

### `rag_pipeline.py` — RAG Pipeline
- FAISS vector store for GIS documentation
- 15+ embedded knowledge chunks (GeoPandas, Rasterio, GDAL, OSM)
- Cosine similarity retrieval fallback
- Automatically enriches KB with validated workflows

### `gis_tools.py` — GIS Execution Engine
- **Vector**: buffer, clip, spatial_join, overlay, dissolve, filter_by_attribute
- **Raster**: slope, aspect, NDVI, threshold, raster-to-vector
- **CRS**: auto-detection, reprojection, mismatch handling
- **Analysis**: area calculation, statistics

### `agent_loop.py` — ReAct Agent Loop
- Layer registry (in-memory GIS output store)
- Thought → Action → Observation pattern
- Auto-retries on failure (configurable)
- Progress callbacks for UI

### `dataset_loader.py` — Data Loaders
- OSM via OSMnx (rivers, roads, landuse, buildings)
- DEM GeoTIFF (SRTM, Cartosat, ALOS)
- GeoJSON, Shapefile, GeoPackage
- Synthetic data generation for demo mode
- Disk caching for loaded datasets

### `visualization.py` — Map Engine
- Multi-layer interactive Folium maps
- Auto-color per layer type
- Tooltips with attribute data
- Raster preview generation

---

## 🗂️ Data Sources

| Source | Type | Notes |
|--------|------|-------|
| OpenStreetMap | Vector | Rivers, roads, land use (via OSMnx) |
| SRTM | Raster DEM | 30m global elevation |
| Cartosat DEM | Raster DEM | 10m India (Bhoonidhi portal) |
| ALOS AW3D30 | Raster DEM | 30m global (JAXA) |
| Bhoonidhi | Various | ISRO India datasets |

---

## 🔧 Configuration

Edit settings in the Streamlit sidebar or set environment variables:

```bash
# LLM
export ANTHROPIC_API_KEY="..."
export OPENAI_API_KEY="..."

# Ollama
export OLLAMA_BASE_URL="http://localhost:11434"
```

---

## 📊 Tool Registry

Tools are defined in `tool_registry.json` with JSON schema:

```json
{
  "tool": "buffer",
  "category": "vector_operations",
  "description": "Create buffer zones around geometries",
  "inputs": ["geometry", "distance_meters"],
  "output": "buffered_geodataframe"
}
```

18 tools across categories: data_loading, vector_operations, raster_operations, crs_operations, analysis, output, visualization.

---

## 🐛 Troubleshooting

**OSMnx import error:**
```bash
pip install osmnx --upgrade
```

**FAISS not available (CPU):**
```bash
pip install faiss-cpu
```

**Ollama connection refused:**
```bash
ollama serve   # Ensure Ollama is running
```

**CRS mismatch warnings:**
The system automatically handles CRS alignment. Check logs for details.

**No map displayed:**
This occurs when all GIS operations produce empty results. Try a different query or location.

---

## 📄 Output Files

After each run, the `outputs/` directory contains:
- `{workflow_id}_workflow.json` — Full workflow definition
- `{workflow_id}_workflow.yaml` — YAML version
- `result_map.html` — Interactive Folium map
- `reasoning_log.txt` — Chain-of-Thought + execution log
- `*.geojson` — Individual GIS output layers (if saved)

---

## 🧪 Running Tests

```bash
# Test individual modules
python dataset_loader.py   # Creates sample data
python gis_tools.py        # Tests GIS operations
python agent_loop.py       # Tests full execution
```
