"""
app.py
======
Main Streamlit Application — Chain-of-Thought GeoSpatial LLM System

UI Features:
  • Natural language query input
  • LLM backend and model selector
  • Real-time Chain-of-Thought reasoning display
  • Animated workflow step visualization
  • Interactive Folium map output
  • JSON/YAML workflow download
  • GIS layer download

Architecture: Query → LLM Reasoning → Workflow → GIS Execution → Map

Author: GeoSpatial LLM System
"""

import os
import json
import time
import tempfile
from pathlib import Path
from datetime import datetime

import streamlit as st
import geopandas as gpd
import numpy as np

# ── Page Config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="GeoSpatial LLM — CoT Workflow System",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────

st.markdown("""
<style>
    /* Import fonts */
    @import url('https://fonts.googleapis.com/css2?family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Syne:wght@400;600;700;800&display=swap');

    /* Global reset */
    .stApp { background: #0a0e1a; }
    
    /* Main header */
    .main-header {
        background: linear-gradient(135deg, #0d1b2a 0%, #1a2744 50%, #0d2233 100%);
        border: 1px solid rgba(88, 166, 255, 0.2);
        border-radius: 16px;
        padding: 28px 36px;
        margin-bottom: 24px;
        position: relative;
        overflow: hidden;
    }
    .main-header::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(ellipse at 30% 20%, rgba(88, 166, 255, 0.08) 0%, transparent 60%),
                    radial-gradient(ellipse at 70% 80%, rgba(99, 102, 241, 0.06) 0%, transparent 60%);
        pointer-events: none;
    }
    .main-header h1 {
        font-family: 'Syne', sans-serif;
        font-weight: 800;
        font-size: 1.9rem;
        color: #f0f6fc;
        margin: 0 0 8px 0;
        letter-spacing: -0.02em;
    }
    .main-header p {
        font-family: 'Space Mono', monospace;
        color: #8b949e;
        font-size: 0.82rem;
        margin: 0;
        letter-spacing: 0.03em;
    }
    .accent { color: #58a6ff; }
    .accent-green { color: #3fb950; }
    .accent-purple { color: #bc8cff; }

    /* Section cards */
    .section-card {
        background: rgba(13, 17, 23, 0.8);
        border: 1px solid rgba(48, 54, 61, 0.8);
        border-radius: 12px;
        padding: 20px 24px;
        margin-bottom: 20px;
        backdrop-filter: blur(8px);
    }
    .section-title {
        font-family: 'Syne', sans-serif;
        font-weight: 700;
        font-size: 1rem;
        color: #f0f6fc;
        margin-bottom: 14px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    /* Reasoning step */
    .reasoning-step {
        font-family: 'Space Mono', monospace;
        font-size: 0.75rem;
        line-height: 1.7;
        color: #c9d1d9;
        background: #0d1117;
        border: 1px solid #21262d;
        border-radius: 8px;
        padding: 14px 18px;
        white-space: pre-wrap;
        max-height: 340px;
        overflow-y: auto;
    }

    /* Workflow steps */
    .workflow-step {
        display: flex;
        align-items: flex-start;
        gap: 14px;
        padding: 12px 16px;
        background: #0d1117;
        border: 1px solid #21262d;
        border-radius: 10px;
        margin-bottom: 8px;
        transition: all 0.3s ease;
        font-family: 'Space Mono', monospace;
    }
    .workflow-step.running {
        border-color: #58a6ff;
        background: rgba(88, 166, 255, 0.06);
    }
    .workflow-step.completed {
        border-color: #3fb950;
        background: rgba(63, 185, 80, 0.04);
    }
    .workflow-step.error {
        border-color: #f85149;
        background: rgba(248, 81, 73, 0.06);
    }
    .step-num {
        width: 28px; height: 28px;
        background: #21262d;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        color: #8b949e; font-size: 0.75rem; font-weight: 700;
        flex-shrink: 0;
    }
    .step-name { color: #f0f6fc; font-size: 0.82rem; font-weight: 600; }
    .step-tool { color: #58a6ff; font-size: 0.72rem; margin-top: 3px; }
    .step-reason { color: #8b949e; font-size: 0.7rem; margin-top: 4px; line-height: 1.5; }

    /* Status badges */
    .badge {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 20px;
        font-size: 0.68rem;
        font-family: 'Space Mono', monospace;
        font-weight: 600;
        letter-spacing: 0.04em;
    }
    .badge-pending { background: #21262d; color: #8b949e; }
    .badge-running { background: rgba(88, 166, 255, 0.15); color: #58a6ff; }
    .badge-done { background: rgba(63, 185, 80, 0.15); color: #3fb950; }
    .badge-error { background: rgba(248, 81, 73, 0.15); color: #f85149; }

    /* Query examples */
    .example-query {
        background: #161b22;
        border: 1px solid #30363d;
        border-radius: 8px;
        padding: 8px 14px;
        cursor: pointer;
        font-family: 'Space Mono', monospace;
        font-size: 0.75rem;
        color: #8b949e;
        margin-bottom: 6px;
        transition: all 0.2s;
    }
    .example-query:hover {
        border-color: #58a6ff;
        color: #c9d1d9;
        background: #0d1117;
    }

    /* Metric cards */
    .metric-row {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        margin-bottom: 16px;
    }
    .metric-card {
        background: #0d1117;
        border: 1px solid #21262d;
        border-radius: 10px;
        padding: 14px 16px;
        text-align: center;
        font-family: 'Space Mono', monospace;
    }
    .metric-value { font-size: 1.8rem; font-weight: 700; color: #58a6ff; }
    .metric-label { font-size: 0.68rem; color: #8b949e; margin-top: 4px; letter-spacing: 0.08em; }

    /* Download buttons area */
    .download-row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 12px; }

    /* Streamlit overrides */
    .stTextArea textarea {
        background-color: #0d1117 !important;
        color: #f0f6fc !important;
        border: 1px solid #30363d !important;
        border-radius: 10px !important;
        font-family: 'Space Mono', monospace !important;
        font-size: 0.85rem !important;
    }
    .stTextArea textarea:focus {
        border-color: #58a6ff !important;
        box-shadow: 0 0 0 3px rgba(88, 166, 255, 0.15) !important;
    }
    .stButton button {
        background: linear-gradient(135deg, #1a7fd4, #1258a8) !important;
        color: white !important;
        border: none !important;
        border-radius: 8px !important;
        font-family: 'Syne', sans-serif !important;
        font-weight: 700 !important;
        letter-spacing: 0.04em !important;
        padding: 0.5rem 1.4rem !important;
        transition: all 0.2s !important;
    }
    .stButton button:hover {
        background: linear-gradient(135deg, #2189e0, #1a6cbf) !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 16px rgba(88, 166, 255, 0.25) !important;
    }
    div[data-testid="stSelectbox"] select,
    div[data-testid="stSelectbox"] > div > div {
        background-color: #0d1117 !important;
        color: #f0f6fc !important;
        border-color: #30363d !important;
    }
    .stProgress > div > div > div > div {
        background: linear-gradient(90deg, #1a7fd4, #58a6ff) !important;
    }
    .element-container { color: #c9d1d9; }
    h1, h2, h3 { color: #f0f6fc !important; }
    .stTabs [data-baseweb="tab"] {
        font-family: 'Space Mono', monospace !important;
        font-size: 0.8rem !important;
        color: #8b949e !important;
    }
    .stTabs [aria-selected="true"] {
        color: #58a6ff !important;
    }
    .sidebar .stSelectbox { margin-bottom: 12px; }
    [data-testid="stSidebar"] {
        background: #0d1117 !important;
        border-right: 1px solid #21262d !important;
    }
    [data-testid="stSidebar"] .stMarkdown p {
        font-family: 'Space Mono', monospace;
        font-size: 0.75rem;
        color: #8b949e;
    }
</style>
""", unsafe_allow_html=True)


# ── Session State Init ────────────────────────────────────────────────────────

def init_session_state():
    defaults = {
        "workflow": None,
        "reasoning_text": "",
        "map_html": None,
        "output_layers": {},
        "execution_complete": False,
        "query": "",
        "step_statuses": {},
        "backend": "ollama",
        "model": "llama3",
        "is_running": False,
        "selected_example": None,
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val


init_session_state()


# ── Header ────────────────────────────────────────────────────────────────────

st.markdown("""
<div class="main-header">
    <h1>🌍 GeoSpatial <span class="accent">LLM</span> — Chain-of-Thought Workflow System</h1>
    <p>AUTOMATED GEOSPATIAL ANALYSIS · POWERED BY LLM REASONING · REACT AGENT LOOP · INTELLIGENT GEOPROCESSING ORCHESTRATION</p>
</div>
""", unsafe_allow_html=True)


# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("## ⚙️ Configuration")

    st.markdown("**LLM Backend**")
    backend = st.selectbox(
        "Backend",
        ["ollama", "anthropic", "openai"],
        index=0,
        label_visibility="collapsed",
    )

    if backend == "ollama":
        model = st.selectbox("Model", ["llama3", "mistral", "mixtral", "llama3:70b", "codellama"])
        st.markdown("""
        <p>⚡ Run Ollama locally:<br><code>ollama pull llama3</code><br><code>ollama serve</code></p>
        """, unsafe_allow_html=True)
    elif backend == "anthropic":
        model = st.selectbox("Model", ["claude-sonnet-4-20250514", "claude-opus-4-20250514"])
        st.text_input("Anthropic API Key", type="password",
                      value=os.getenv("ANTHROPIC_API_KEY", ""),
                      key="anthropic_key")
    else:
        model = st.selectbox("Model", ["gpt-4o", "gpt-4o-mini"])
        st.text_input("OpenAI API Key", type="password",
                      value=os.getenv("OPENAI_API_KEY", ""),
                      key="openai_key")

    st.divider()
    st.markdown("**Analysis Settings**")
    buffer_distance = st.slider("Default Buffer Distance (m)", 100, 5000, 1000, 100)
    elevation_threshold = st.slider("Low Elevation Threshold (m)", 10, 200, 50, 5)

    st.divider()
    st.markdown("**Data Sources**")
    use_osm = st.checkbox("OpenStreetMap (Live)", value=True)
    use_synthetic = st.checkbox("Synthetic Demo Data", value=True,
                                help="Generate synthetic data when real data unavailable")

    st.divider()
    st.markdown("**About**")
    st.markdown("""
    <p>Chain-of-Thought LLM system for automated GIS workflow generation.<br><br>
    <strong>Stack:</strong><br>
    LangChain · FAISS · GeoPandas<br>
    Rasterio · Folium · Streamlit<br><br>
    <strong>Supports:</strong><br>
    Flood Risk · Site Suitability<br>
    Vegetation Analysis · More</p>
    """, unsafe_allow_html=True)


# ── Main Layout ───────────────────────────────────────────────────────────────

col_left, col_right = st.columns([1, 1.4], gap="large")

# ── Left Column: Input & Reasoning ───────────────────────────────────────────

with col_left:

    # ── Query Input ──
    st.markdown("""<div class="section-title">🔍 Natural Language Query</div>""", unsafe_allow_html=True)

    # Example queries
    EXAMPLE_QUERIES = [
        "Find flood-prone areas near rivers in Assam, India",
        "Identify suitable locations for solar farms in Rajasthan",
        "Analyze vegetation health and NDVI in a forest region",
        "Find areas suitable for urban expansion avoiding forests",
        "Identify low-lying areas prone to waterlogging near streams",
    ]

    with st.expander("💡 Example Queries — click to load"):
        for eq in EXAMPLE_QUERIES:
            if st.button(f"→ {eq}", key=f"eq_{eq[:20]}", use_container_width=True):
                st.session_state["selected_example"] = eq

    # Determine query value
    query_val = st.session_state.get("selected_example") or st.session_state.get("query", "")
    if st.session_state.get("selected_example"):
        st.session_state["selected_example"] = None

    query = st.text_area(
        "Enter your geospatial analysis query:",
        value=query_val,
        height=90,
        placeholder="e.g., Find flood-prone areas near rivers in Assam, India",
        label_visibility="collapsed",
    )
    st.session_state["query"] = query

    col_run, col_reset = st.columns([3, 1])
    with col_run:
        run_btn = st.button(
            "🚀 Generate & Execute Workflow",
            use_container_width=True,
            disabled=st.session_state.get("is_running", False),
        )
    with col_reset:
        if st.button("🔄 Reset", use_container_width=True):
            for key in ["workflow", "reasoning_text", "map_html", "output_layers",
                        "execution_complete", "step_statuses", "is_running"]:
                st.session_state[key] = None if key not in ["output_layers", "step_statuses"] else {}
            st.session_state["execution_complete"] = False
            st.session_state["is_running"] = False
            st.rerun()

    # ── Chain-of-Thought Display ──
    st.markdown("""<div class="section-title" style="margin-top:24px;">🧠 Chain-of-Thought Reasoning</div>""", unsafe_allow_html=True)

    reasoning_placeholder = st.empty()

    if st.session_state.get("reasoning_text"):
        with reasoning_placeholder.container():
            st.markdown(
                f'<div class="reasoning-step">{st.session_state["reasoning_text"]}</div>',
                unsafe_allow_html=True
            )
    else:
        with reasoning_placeholder.container():
            st.markdown(
                '<div class="reasoning-step" style="color:#484f58; text-align:center; padding:40px 0;">Reasoning steps will appear here after query submission...</div>',
                unsafe_allow_html=True
            )

    # ── Workflow Steps ──
    if st.session_state.get("workflow"):
        st.markdown("""<div class="section-title" style="margin-top:24px;">⚡ Workflow Steps</div>""", unsafe_allow_html=True)

        workflow = st.session_state["workflow"]
        steps = workflow.get("steps", [])

        for step in steps:
            sid = step.get("step_id", "?")
            status = step.get("status", "pending")
            status_class = {"pending": "", "running": "running", "completed": "completed", "error": "error"}.get(status, "")
            badge_class = {"pending": "badge-pending", "running": "badge-running", "completed": "badge-done", "error": "badge-error"}.get(status, "badge-pending")
            badge_label = {"pending": "PENDING", "running": "RUNNING", "completed": "DONE", "error": "ERROR"}.get(status, "PENDING")
            icon = {"pending": "○", "running": "⟳", "completed": "✓", "error": "✗"}.get(status, "○")

            st.markdown(f"""
            <div class="workflow-step {status_class}">
                <div class="step-num">{icon}</div>
                <div style="flex:1">
                    <div style="display:flex; justify-content:space-between; align-items:center">
                        <span class="step-name">{step.get('name', f'Step {sid}')}</span>
                        <span class="badge {badge_class}">{badge_label}</span>
                    </div>
                    <div class="step-tool">🔧 {step.get('tool', 'unknown')}</div>
                    <div class="step-reason">{step.get('reasoning', step.get('description', ''))[:120]}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)


# ── Right Column: Map & Outputs ───────────────────────────────────────────────

with col_right:

    st.markdown("""<div class="section-title">🗺️ Interactive Map Output</div>""", unsafe_allow_html=True)

    map_placeholder = st.empty()
    metrics_placeholder = st.empty()

    if st.session_state.get("map_html"):
        with map_placeholder.container():
            from streamlit_folium import folium_static
            import folium
            # Rebuild map from saved HTML
            m = folium.Map(location=[26.2, 92.9], zoom_start=8)
            st.components.v1.html(st.session_state["map_html"], height=460, scrolling=False)
    else:
        with map_placeholder.container():
            st.markdown("""
            <div style="height:460px; background:#0d1117; border:1px solid #21262d;
                        border-radius:12px; display:flex; flex-direction:column;
                        align-items:center; justify-content:center; gap:16px;">
                <div style="font-size:3rem;">🌍</div>
                <div style="font-family:'Space Mono',monospace; color:#484f58; font-size:0.82rem; text-align:center;">
                    Map visualization will appear here<br>after workflow execution
                </div>
            </div>
            """, unsafe_allow_html=True)

    # ── Statistics & Downloads ──
    if st.session_state.get("execution_complete") and st.session_state.get("workflow"):
        workflow = st.session_state["workflow"]
        stats = workflow.get("statistics", {})

        with metrics_placeholder.container():
            st.markdown("""<div class="section-title" style="margin-top:20px;">📊 Results & Downloads</div>""", unsafe_allow_html=True)

            # Metrics row
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                st.metric("Total Steps", stats.get("total_steps", 0))
            with c2:
                st.metric("Completed", stats.get("completed", 0),
                          delta=f"+{stats.get('completed', 0)}")
            with c3:
                st.metric("Failed", stats.get("failed", 0))
            with c4:
                layers_count = len(workflow.get("outputs", {}))
                st.metric("Layers", layers_count)

            # Tabs for outputs
            tab_json, tab_yaml, tab_layers, tab_log = st.tabs(["📋 JSON Workflow", "📄 YAML Workflow", "📦 Download Layers", "📜 Execution Log"])

            with tab_json:
                from workflow_generator import WorkflowGenerator
                gen = WorkflowGenerator("tool_registry.json")
                # Export workflow without non-serializable data
                export_wf = {k: v for k, v in workflow.items() if k not in ("outputs",)}
                json_str = gen.to_json(export_wf)
                st.code(json_str[:3000] + ("..." if len(json_str) > 3000 else ""), language="json")
                st.download_button("⬇️ Download JSON", json_str,
                                   file_name=f"{workflow.get('workflow_id', 'workflow')}.json",
                                   mime="application/json")

            with tab_yaml:
                yaml_str = gen.to_yaml(export_wf)
                st.code(yaml_str[:2000] + ("..." if len(yaml_str) > 2000 else ""), language="yaml")
                st.download_button("⬇️ Download YAML", yaml_str,
                                   file_name=f"{workflow.get('workflow_id', 'workflow')}.yaml",
                                   mime="text/yaml")

            with tab_layers:
                output_layers = st.session_state.get("output_layers", {})
                if output_layers:
                    for layer_name, gdf in output_layers.items():
                        if isinstance(gdf, gpd.GeoDataFrame) and len(gdf) > 0:
                            with st.expander(f"📍 {layer_name.replace('_', ' ').title()} ({len(gdf)} features)"):
                                st.dataframe(gdf.drop(columns=["geometry"]).head(5), use_container_width=True)

                                # Download as GeoJSON
                                geojson_str = gdf.to_json()
                                st.download_button(
                                    f"⬇️ Download {layer_name}.geojson",
                                    geojson_str,
                                    file_name=f"{layer_name}.geojson",
                                    mime="application/geo+json",
                                    key=f"dl_{layer_name}",
                                )
                else:
                    st.info("No vector layers to download.")

            with tab_log:
                reasoning_log = workflow.get("reasoning_log", [])
                if reasoning_log:
                    log_text = "\n".join(reasoning_log)
                    st.text_area("Execution Log", log_text, height=250, label_visibility="collapsed")
                    st.download_button("⬇️ Download Log", log_text,
                                       file_name="reasoning_log.txt", mime="text/plain")
                else:
                    st.info("No execution log available.")


# ── Execution Logic ───────────────────────────────────────────────────────────

def run_full_pipeline(
    query: str,
    backend: str,
    model: str,
    buffer_dist: int,
    elev_threshold: int,
):
    """
    Run the complete pipeline:
    1. RAG retrieval
    2. LLM Chain-of-Thought reasoning
    3. Workflow generation
    4. GIS execution
    5. Map visualization
    """
    from llm_engine import LLMEngine
    from rag_pipeline import RAGPipeline, get_tool_descriptions
    from workflow_generator import WorkflowGenerator
    from agent_loop import AgentLoop
    from visualization import create_folium_map, save_map

    # ── Status indicator ──
    status_area = st.empty()
    progress_bar = st.progress(0)

    def update_status(msg: str, pct: float):
        status_area.markdown(
            f'<div style="font-family:Space Mono,monospace; font-size:0.8rem; '
            f'color:#58a6ff; padding:8px 0;">{msg}</div>',
            unsafe_allow_html=True
        )
        progress_bar.progress(pct)

    try:
        # ── Step 1: Initialize LLM ──
        update_status("🔧 Initializing LLM engine...", 0.05)

        if backend == "anthropic" and st.session_state.get("anthropic_key"):
            os.environ["ANTHROPIC_API_KEY"] = st.session_state["anthropic_key"]
        if backend == "openai" and st.session_state.get("openai_key"):
            os.environ["OPENAI_API_KEY"] = st.session_state["openai_key"]

        llm = LLMEngine(backend=backend, model=model, temperature=0.1)

        # ── Step 2: RAG Retrieval ──
        update_status("📚 Retrieving GIS documentation...", 0.15)
        rag = RAGPipeline(knowledge_base_path="knowledge_base")
        rag_context = rag.retrieve_and_format(query, top_k=4)
        tool_list = get_tool_descriptions("tool_registry.json")

        # ── Step 3: LLM CoT Reasoning ──
        update_status("🧠 Running Chain-of-Thought reasoning...", 0.25)
        cot_text, llm_workflow = llm.reason_and_plan(
            query=query,
            rag_context=rag_context,
            tool_list=tool_list,
        )

        # Update reasoning display
        st.session_state["reasoning_text"] = cot_text
        reasoning_placeholder.markdown(
            f'<div class="reasoning-step">{cot_text[:2000]}...</div>',
            unsafe_allow_html=True
        )

        # ── Step 4: Workflow Generation ──
        update_status("⚙️ Generating workflow definition...", 0.40)
        gen = WorkflowGenerator("tool_registry.json")
        workflow = gen.from_llm_output(llm_workflow, query)

        # Override some params from UI
        for step in workflow.get("steps", []):
            if step["tool"] == "buffer" and "distance_meters" not in step.get("inputs", {}):
                step["inputs"]["distance_meters"] = buffer_dist
            if step["tool"] == "raster_threshold":
                if step["inputs"].get("operator") in ("<", "<="):
                    step["inputs"]["threshold_value"] = elev_threshold

        st.session_state["workflow"] = workflow

        # ── Step 5: GIS Execution ──
        update_status("🗺️ Executing GIS workflow...", 0.50)
        agent = AgentLoop(output_dir="outputs")

        total_steps = len(workflow.get("steps", []))
        step_progress_base = 0.50
        step_progress_range = 0.35

        def progress_cb(step_id, message):
            pct = step_progress_base + (step_id / max(total_steps, 1)) * step_progress_range
            update_status(f"🔧 {message}", min(pct, 0.84))
            # Force rerun not ideal in Streamlit — update steps display
            if workflow.get("steps"):
                st.session_state["workflow"] = workflow

        executed_workflow = agent.execute_workflow(workflow, progress_callback=progress_cb)
        st.session_state["workflow"] = executed_workflow

        # ── Step 6: Collect Outputs ──
        update_status("📦 Collecting output layers...", 0.87)
        output_layers = agent.get_final_outputs()
        st.session_state["output_layers"] = output_layers

        # Persist stats
        rag.add_workflow_example(query, executed_workflow)

        # ── Step 7: Map Visualization ──
        update_status("🗺️ Generating interactive map...", 0.92)
        if output_layers:
            try:
                import folium
                from visualization import create_folium_map

                m = create_folium_map(output_layers, zoom_start=8)

                # Render map
                from streamlit_folium import folium_static
                map_placeholder.empty()
                with map_placeholder.container():
                    folium_static(m, width=None, height=460)

                # Save HTML
                map_path = "outputs/result_map.html"
                m.save(map_path)
                with open(map_path) as f:
                    st.session_state["map_html"] = f.read()

            except Exception as e:
                st.warning(f"Map generation issue (data still available): {e}")

        # ── Complete ──
        update_status("✅ Workflow execution complete!", 1.0)
        st.session_state["execution_complete"] = True
        time.sleep(1)
        status_area.empty()
        progress_bar.empty()

    except Exception as e:
        status_area.error(f"Pipeline error: {str(e)}")
        progress_bar.empty()
        import traceback
        st.exception(e)
    finally:
        st.session_state["is_running"] = False


# ── Run on Button Click ───────────────────────────────────────────────────────

if run_btn and query.strip():
    st.session_state["is_running"] = True
    st.session_state["execution_complete"] = False
    st.session_state["workflow"] = None
    st.session_state["output_layers"] = {}
    st.session_state["map_html"] = None
    st.session_state["reasoning_text"] = ""

    with st.spinner(""):
        run_full_pipeline(
            query=query,
            backend=backend,
            model=model,
            buffer_dist=buffer_distance,
            elev_threshold=elevation_threshold,
        )
    st.rerun()

elif run_btn and not query.strip():
    st.warning("⚠️ Please enter a geospatial query before running.")


# ── Architecture Diagram (collapsible) ───────────────────────────────────────

with st.expander("🏗️ System Architecture Overview"):
    st.markdown("""
    <div style="font-family:'Space Mono',monospace; font-size:0.75rem; color:#8b949e; line-height:1.9; background:#0d1117; padding:18px 24px; border-radius:10px; border:1px solid #21262d;">
    <span style="color:#58a6ff; font-weight:700;">PIPELINE ARCHITECTURE</span><br><br>
    
    <span style="color:#3fb950;">USER QUERY</span> ──► <span style="color:#58a6ff;">LLM ENGINE</span> (Ollama / Claude / GPT)<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;↕ <span style="color:#bc8cff;">RAG PIPELINE</span> (FAISS vector store)<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;↓<br>
    <span style="color:#3fb950;">CHAIN-OF-THOUGHT</span> ──► <span style="color:#58a6ff;">WORKFLOW GENERATOR</span> (JSON/YAML)<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;↓<br>
    <span style="color:#3fb950;">AGENT LOOP</span> ──► <span style="color:#58a6ff;">GIS EXECUTION ENGINE</span><br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;↓&nbsp;&nbsp;&nbsp;→ GeoPandas (vector ops)<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;→ Rasterio (raster ops)<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;→ OSMnx (data loading)<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;↓<br>
    <span style="color:#3fb950;">OUTPUT</span> ──► <span style="color:#58a6ff;">FOLIUM MAP</span> + JSON/YAML + GeoJSON downloads<br>
    <br>
    <span style="color:#484f58;">ReAct Loop: Thought → Action (GIS tool) → Observation → Refinement</span>
    </div>
    """, unsafe_allow_html=True)
