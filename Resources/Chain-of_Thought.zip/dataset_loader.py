"""
dataset_loader.py
=================
Unified data loader for geospatial datasets.

Supports:
  - OpenStreetMap (via OSMnx)
  - DEM GeoTIFF files (SRTM, Cartosat)
  - GeoJSON / Shapefiles / GeoPackage
  - Synthetic demo datasets (when real data unavailable)

Includes caching, CRS validation, and geometry repair.

Author: GeoSpatial LLM System
"""

import os
import json
import hashlib
import pickle
from pathlib import Path
from typing import Optional, Union
from loguru import logger

import numpy as np
import geopandas as gpd
from shapely.geometry import box, Point, LineString, Polygon, MultiPolygon
from shapely.validation import make_valid


# ── Cache Setup ───────────────────────────────────────────────────────────────

CACHE_DIR = Path("data/.cache")
CACHE_DIR.mkdir(parents=True, exist_ok=True)


def _cache_key(params: dict) -> str:
    """Generate deterministic cache key from parameters."""
    key_str = json.dumps(params, sort_keys=True)
    return hashlib.md5(key_str.encode()).hexdigest()


def _load_from_cache(cache_key: str):
    """Load GeoDataFrame from disk cache."""
    cache_file = CACHE_DIR / f"{cache_key}.pkl"
    if cache_file.exists():
        try:
            with open(cache_file, "rb") as f:
                return pickle.load(f)
        except Exception as e:
            logger.warning(f"Cache read failed: {e}")
    return None


def _save_to_cache(cache_key: str, data):
    """Save GeoDataFrame to disk cache."""
    try:
        cache_file = CACHE_DIR / f"{cache_key}.pkl"
        with open(cache_file, "wb") as f:
            pickle.dump(data, f)
        logger.debug(f"Saved to cache: {cache_key}")
    except Exception as e:
        logger.warning(f"Cache write failed: {e}")


# ── Geometry Validation ───────────────────────────────────────────────────────

def validate_and_repair_geometries(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """
    Validate and repair invalid geometries in a GeoDataFrame.

    Fixes: self-intersections, duplicate points, ring issues.

    Args:
        gdf: Input GeoDataFrame

    Returns:
        GeoDataFrame with validated geometries
    """
    initial_count = len(gdf)
    invalid_mask = ~gdf.geometry.is_valid
    invalid_count = invalid_mask.sum()

    if invalid_count > 0:
        logger.warning(f"Found {invalid_count}/{initial_count} invalid geometries. Repairing...")
        gdf = gdf.copy()
        gdf.loc[invalid_mask, "geometry"] = gdf.loc[invalid_mask, "geometry"].apply(make_valid)
        still_invalid = ~gdf.geometry.is_valid
        if still_invalid.any():
            logger.warning(f"Dropping {still_invalid.sum()} geometries that could not be repaired")
            gdf = gdf[~still_invalid].copy()

    # Remove null geometries
    null_mask = gdf.geometry.isna() | gdf.geometry.is_empty
    if null_mask.any():
        logger.warning(f"Removing {null_mask.sum()} null/empty geometries")
        gdf = gdf[~null_mask].copy()

    gdf = gdf.reset_index(drop=True)
    logger.info(f"Geometry validation complete: {len(gdf)}/{initial_count} features retained")
    return gdf


def ensure_crs(
    gdf: gpd.GeoDataFrame,
    default_crs: str = "EPSG:4326"
) -> gpd.GeoDataFrame:
    """
    Ensure GeoDataFrame has a valid CRS, assigning default if missing.

    Args:
        gdf: Input GeoDataFrame
        default_crs: CRS to assign if none is set

    Returns:
        GeoDataFrame with guaranteed CRS
    """
    if gdf.crs is None:
        logger.warning(f"No CRS found. Assigning {default_crs}")
        gdf = gdf.set_crs(default_crs)
    return gdf


# ── OSM Data Loading ──────────────────────────────────────────────────────────

OSM_TAG_MAP = {
    "waterways": {"waterway": True},
    "rivers": {"waterway": ["river", "stream", "canal", "drain"]},
    "roads": {"highway": ["primary", "secondary", "tertiary", "motorway", "trunk"]},
    "buildings": {"building": True},
    "forests": {"landuse": "forest"},
    "landuse": {"landuse": True},
    "water_bodies": {"natural": "water"},
    "parks": {"leisure": "park"},
    "industrial": {"landuse": "industrial"},
    "residential": {"landuse": "residential"},
}


def load_osm(
    place_name: str,
    feature_type: str = "waterways",
    use_cache: bool = True,
    bbox: Optional[tuple] = None,
) -> gpd.GeoDataFrame:
    """
    Load features from OpenStreetMap.

    Args:
        place_name: Place name (e.g., "Assam, India")
        feature_type: Feature type key from OSM_TAG_MAP
        use_cache: Whether to use cached data
        bbox: Optional (north, south, east, west) bounding box

    Returns:
        GeoDataFrame with OSM features
    """
    cache_key = _cache_key({"place": place_name, "feature": feature_type, "bbox": bbox})

    if use_cache:
        cached = _load_from_cache(cache_key)
        if cached is not None:
            logger.info(f"Loaded {feature_type} from cache ({place_name})")
            return cached

    tags = OSM_TAG_MAP.get(feature_type, {feature_type: True})
    logger.info(f"Loading OSM {feature_type} for {place_name}...")

    try:
        import osmnx as ox
        ox.settings.log_console = False

        if bbox:
            north, south, east, west = bbox
            gdf = ox.features_from_bbox(north, south, east, west, tags=tags)
        else:
            gdf = ox.features_from_place(place_name, tags=tags)

        gdf = gdf.reset_index()
        gdf = ensure_crs(gdf)
        gdf = validate_and_repair_geometries(gdf)

        # Simplify columns
        keep_cols = ["geometry"] + [c for c in gdf.columns if c in [
            "name", "waterway", "highway", "landuse", "building", "natural",
            "leisure", "amenity", "osmid", "element_type"
        ]]
        gdf = gdf[[c for c in keep_cols if c in gdf.columns]].copy()

        if use_cache:
            _save_to_cache(cache_key, gdf)

        logger.info(f"Loaded {len(gdf)} OSM {feature_type} features from {place_name}")
        return gdf

    except ImportError:
        logger.warning("osmnx not installed. Generating synthetic OSM data.")
        return _generate_synthetic_osm(feature_type, place_name)
    except Exception as e:
        logger.warning(f"OSM loading failed ({e}). Generating synthetic data.")
        return _generate_synthetic_osm(feature_type, place_name)


def _generate_synthetic_osm(feature_type: str, place_name: str) -> gpd.GeoDataFrame:
    """Generate synthetic OSM-like data for demo purposes."""
    import random
    random.seed(42)

    # Approximate centers for known places
    centers = {
        "assam": (26.2, 92.9),
        "rajasthan": (27.0, 74.0),
        "india": (22.0, 80.0),
    }
    place_lower = place_name.lower()
    lat0, lon0 = next(
        (v for k, v in centers.items() if k in place_lower), (26.2, 92.9)
    )

    features = []
    n = 20

    if feature_type in ("waterways", "rivers"):
        for i in range(n):
            lat = lat0 + random.uniform(-1.5, 1.5)
            lon = lon0 + random.uniform(-1.5, 1.5)
            line = LineString([
                (lon, lat),
                (lon + random.uniform(0.1, 0.5), lat + random.uniform(-0.2, 0.2)),
                (lon + random.uniform(0.3, 0.8), lat + random.uniform(-0.1, 0.1)),
            ])
            features.append({"geometry": line, "waterway": random.choice(["river", "stream"]), "name": f"River_{i}"})

    elif feature_type in ("roads",):
        for i in range(n):
            lat = lat0 + random.uniform(-1.5, 1.5)
            lon = lon0 + random.uniform(-1.5, 1.5)
            line = LineString([
                (lon, lat),
                (lon + random.uniform(0.05, 0.3), lat + random.uniform(-0.05, 0.05)),
            ])
            features.append({"geometry": line, "highway": random.choice(["primary", "secondary"]), "name": f"Road_{i}"})

    elif feature_type in ("forests", "landuse"):
        for i in range(n):
            lat = lat0 + random.uniform(-1.5, 1.5)
            lon = lon0 + random.uniform(-1.5, 1.5)
            sz = random.uniform(0.05, 0.2)
            poly = box(lon, lat, lon + sz, lat + sz)
            features.append({"geometry": poly, "landuse": "forest", "name": f"Forest_{i}"})

    else:
        for i in range(n):
            lat = lat0 + random.uniform(-1.5, 1.5)
            lon = lon0 + random.uniform(-1.5, 1.5)
            sz = random.uniform(0.02, 0.1)
            poly = box(lon, lat, lon + sz, lat + sz)
            features.append({"geometry": poly, "name": f"Feature_{i}"})

    gdf = gpd.GeoDataFrame(features, crs="EPSG:4326")
    logger.info(f"Generated {len(gdf)} synthetic {feature_type} features for {place_name}")
    return gdf


# ── Raster Loading ────────────────────────────────────────────────────────────

def load_raster(file_path: str) -> dict:
    """
    Load raster dataset from GeoTIFF file.

    Args:
        file_path: Path to GeoTIFF file

    Returns:
        Dictionary with keys: data (numpy array), profile, transform, crs, nodata
    """
    import rasterio

    logger.info(f"Loading raster: {file_path}")
    try:
        with rasterio.open(file_path) as src:
            data = src.read()  # All bands
            profile = src.profile.copy()
            return {
                "data": data,
                "profile": profile,
                "transform": src.transform,
                "crs": src.crs,
                "nodata": src.nodata,
                "bounds": src.bounds,
                "shape": (src.height, src.width),
                "bands": src.count,
                "file_path": file_path,
            }
    except FileNotFoundError:
        logger.warning(f"Raster file not found: {file_path}. Generating synthetic DEM.")
        return generate_synthetic_dem()
    except Exception as e:
        logger.warning(f"Raster load failed: {e}. Generating synthetic DEM.")
        return generate_synthetic_dem()


def generate_synthetic_dem(
    lat0: float = 26.0,
    lon0: float = 92.5,
    size: int = 256,
    resolution: float = 0.001,
    seed: int = 42,
) -> dict:
    """
    Generate a synthetic DEM for demonstration purposes.

    Creates realistic terrain using Perlin-like noise with rivers.

    Args:
        lat0, lon0: Bottom-left corner coordinates
        size: Grid size in pixels
        resolution: Pixel size in degrees
        seed: Random seed

    Returns:
        Raster dictionary compatible with load_raster output
    """
    import rasterio
    from rasterio.transform import from_bounds
    from scipy.ndimage import gaussian_filter

    logger.info(f"Generating synthetic DEM ({size}x{size}) centered near ({lat0},{lon0})")

    rng = np.random.RandomState(seed)

    # Base elevation field (multi-scale)
    elevation = np.zeros((size, size))
    for scale, amplitude in [(8, 200), (16, 100), (32, 50), (64, 25)]:
        coarse = rng.randn(size // scale, size // scale) * amplitude
        from scipy.ndimage import zoom
        fine = zoom(coarse, scale, order=1)
        elevation += fine[:size, :size]

    # Add minimum elevation base (20m)
    elevation = elevation - elevation.min() + 20

    # Carve river valley (diagonal from NE to SW)
    for i in range(size):
        j = int(size * 0.3 + i * 0.4)
        if 0 <= j < size:
            for dj in range(-15, 15):
                jj = j + dj
                if 0 <= jj < size:
                    depth = max(0, 30 - abs(dj) * 3)
                    elevation[i, jj] -= depth

    # Smooth
    elevation = gaussian_filter(elevation, sigma=2)
    elevation = np.clip(elevation, 0, 500).astype(np.float32)

    transform = from_bounds(
        lon0, lat0,
        lon0 + size * resolution, lat0 + size * resolution,
        size, size
    )

    profile = {
        "driver": "GTiff",
        "dtype": "float32",
        "width": size,
        "height": size,
        "count": 1,
        "crs": "EPSG:4326",
        "transform": transform,
        "nodata": -9999,
    }

    import rasterio.crs
    return {
        "data": elevation[np.newaxis, :, :],
        "profile": profile,
        "transform": transform,
        "crs": rasterio.crs.CRS.from_epsg(4326),
        "nodata": -9999,
        "bounds": (lon0, lat0, lon0 + size * resolution, lat0 + size * resolution),
        "shape": (size, size),
        "bands": 1,
        "file_path": "synthetic_dem",
    }


# ── Vector File Loading ───────────────────────────────────────────────────────

def load_vector(
    file_path: str,
    layer: Optional[str] = None,
    target_crs: Optional[str] = None,
) -> gpd.GeoDataFrame:
    """
    Load vector data from GeoJSON, Shapefile, GeoPackage.

    Args:
        file_path: Path to vector file
        layer: Layer name (for GeoPackage with multiple layers)
        target_crs: Optional CRS to reproject to after loading

    Returns:
        GeoDataFrame
    """
    logger.info(f"Loading vector: {file_path}")
    try:
        kwargs = {}
        if layer:
            kwargs["layer"] = layer

        gdf = gpd.read_file(file_path, **kwargs)
        gdf = ensure_crs(gdf)
        gdf = validate_and_repair_geometries(gdf)

        if target_crs:
            gdf = gdf.to_crs(target_crs)
            logger.info(f"Reprojected to {target_crs}")

        logger.info(f"Loaded {len(gdf)} features from {file_path}")
        return gdf

    except FileNotFoundError:
        logger.error(f"File not found: {file_path}")
        raise
    except Exception as e:
        logger.error(f"Vector load failed: {e}")
        raise


def load_geojson_from_dict(data: dict) -> gpd.GeoDataFrame:
    """
    Create GeoDataFrame from a GeoJSON dictionary.

    Args:
        data: GeoJSON FeatureCollection dict

    Returns:
        GeoDataFrame
    """
    import io
    gdf = gpd.read_file(io.StringIO(json.dumps(data)))
    return ensure_crs(gdf)


# ── Sample Data Creator ───────────────────────────────────────────────────────

def create_sample_data(output_dir: str = "data/sample") -> dict:
    """
    Create sample geospatial datasets for demo and testing.

    Generates:
    - Rivers GeoJSON (Assam, India region)
    - Forest polygons GeoJSON
    - Study area boundary GeoJSON
    - Synthetic DEM GeoTIFF

    Args:
        output_dir: Directory to save sample files

    Returns:
        Dictionary of file paths
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    files = {}

    # Study area: Assam bounding box
    study_area = gpd.GeoDataFrame(
        {"name": ["Assam_Study_Area"]},
        geometry=[box(91.0, 25.5, 94.5, 27.5)],
        crs="EPSG:4326",
    )
    path = str(output_path / "study_area.geojson")
    study_area.to_file(path, driver="GeoJSON")
    files["study_area"] = path
    logger.info(f"Created study_area.geojson")

    # Rivers
    rivers_gdf = _generate_synthetic_osm("rivers", "Assam, India")
    path = str(output_path / "rivers.geojson")
    rivers_gdf.to_file(path, driver="GeoJSON")
    files["rivers"] = path
    logger.info(f"Created rivers.geojson ({len(rivers_gdf)} features)")

    # Forests
    forests_gdf = _generate_synthetic_osm("forests", "Assam, India")
    path = str(output_path / "forests.geojson")
    forests_gdf.to_file(path, driver="GeoJSON")
    files["forests"] = path
    logger.info(f"Created forests.geojson ({len(forests_gdf)} features)")

    # Roads
    roads_gdf = _generate_synthetic_osm("roads", "Assam, India")
    path = str(output_path / "roads.geojson")
    roads_gdf.to_file(path, driver="GeoJSON")
    files["roads"] = path

    # DEM GeoTIFF
    try:
        import rasterio
        from rasterio.transform import from_bounds

        dem_data = generate_synthetic_dem(lat0=25.5, lon0=91.0, size=256)
        dem_path = str(output_path / "dem_assam.tif")
        with rasterio.open(dem_path, "w", **dem_data["profile"]) as dst:
            dst.write(dem_data["data"])
        files["dem"] = dem_path
        logger.info(f"Created dem_assam.tif (256x256)")
    except Exception as e:
        logger.warning(f"Could not create DEM file: {e}")

    return files


if __name__ == "__main__":
    # Create sample datasets
    files = create_sample_data("data/sample")
    print("Created sample datasets:")
    for name, path in files.items():
        print(f"  {name}: {path}")
