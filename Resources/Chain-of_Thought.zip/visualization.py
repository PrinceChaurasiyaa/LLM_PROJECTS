"""
visualization.py
================
Map visualization engine using Folium for interactive maps.

Creates:
  - Multi-layer interactive Folium maps
  - Choropleth maps for analysis results
  - Raster overlay visualizations
  - Statistics panels and legends

Author: GeoSpatial LLM System
"""

import json
import colorsys
from pathlib import Path
from typing import Optional, Union
from loguru import logger

import numpy as np
import geopandas as gpd
import folium
from folium import GeoJson, GeoJsonTooltip, FeatureGroup


# ── Color Schemes ─────────────────────────────────────────────────────────────

LAYER_COLORS = {
    "rivers": "#1E90FF",
    "waterways": "#1E90FF",
    "river_buffer": "#87CEEB",
    "low_elev_zones": "#FFD700",
    "flood_risk_zones": "#FF4500",
    "flood_risk_final": "#DC143C",
    "dem_raw": "#8FBC8F",
    "slope": "#DEB887",
    "forests": "#228B22",
    "exclusion_zones": "#8B0000",
    "roads": "#808080",
    "road_buffer": "#C0C0C0",
    "flat_areas_vector": "#90EE90",
    "solar_suitable_zones": "#FFD700",
    "candidate_sites": "#FFA500",
    "vegetation_zones": "#006400",
    "default": "#4682B4",
}

LAYER_DISPLAY_NAMES = {
    "rivers": "🌊 Rivers",
    "waterways": "🌊 Waterways",
    "river_buffer": "💧 River Buffer Zone",
    "low_elev_zones": "🏔️ Low Elevation Areas",
    "flood_risk_zones": "🌊 Flood Risk Zones",
    "flood_risk_final": "⚠️ High Flood Risk",
    "forests": "🌳 Forest Areas",
    "roads": "🛣️ Roads",
    "road_buffer": "🛣️ Road Access Zone",
    "flat_areas_vector": "⛰️ Flat Terrain",
    "solar_suitable_zones": "☀️ Solar Suitable Areas",
    "vegetation_zones": "🌿 Vegetation Cover",
    "default": "📍 Layer",
}


def create_folium_map(
    layers: dict[str, gpd.GeoDataFrame],
    center: Optional[tuple] = None,
    zoom_start: int = 9,
    basemap: str = "CartoDB positron",
) -> folium.Map:
    """
    Create an interactive Folium map with multiple vector layers.

    Args:
        layers: Dict of {layer_name: GeoDataFrame}
        center: (lat, lon) map center. Auto-detected if None.
        zoom_start: Initial zoom level
        basemap: Folium tile layer name

    Returns:
        Folium Map object
    """
    if not layers:
        logger.warning("No layers provided for map. Creating empty map.")
        center = center or (26.2, 92.9)
        return folium.Map(location=center, zoom_start=zoom_start, tiles=basemap)

    # Auto-detect center from layers
    if center is None:
        all_bounds = []
        for gdf in layers.values():
            if len(gdf) > 0:
                bounds = gdf.to_crs("EPSG:4326").total_bounds
                all_bounds.append(bounds)

        if all_bounds:
            all_bounds = np.array(all_bounds)
            minx = all_bounds[:, 0].min()
            miny = all_bounds[:, 1].min()
            maxx = all_bounds[:, 2].max()
            maxy = all_bounds[:, 3].max()
            center = ((miny + maxy) / 2, (minx + maxx) / 2)
        else:
            center = (26.2, 92.9)

    # Create base map
    m = folium.Map(
        location=center,
        zoom_start=zoom_start,
        tiles=basemap,
        control_scale=True,
    )

    # Add additional tile layers
    folium.TileLayer("OpenStreetMap", name="OpenStreetMap").add_to(m)

    # Add each vector layer
    for layer_name, gdf in layers.items():
        if gdf is None or len(gdf) == 0:
            logger.debug(f"Skipping empty layer: {layer_name}")
            continue

        try:
            _add_vector_layer(m, gdf, layer_name)
        except Exception as e:
            logger.warning(f"Could not add layer '{layer_name}' to map: {e}")

    # Add layer control
    folium.LayerControl(collapsed=False).add_to(m)

    # Add fullscreen button
    try:
        from folium.plugins import Fullscreen
        Fullscreen().add_to(m)
    except Exception:
        pass

    logger.info(f"Map created with {len(layers)} layers, center={center}")
    return m


def _add_vector_layer(
    m: folium.Map,
    gdf: gpd.GeoDataFrame,
    layer_name: str,
    opacity: float = 0.7,
):
    """
    Add a single vector layer to a Folium map.

    Args:
        m: Folium Map
        gdf: GeoDataFrame to add
        layer_name: Layer identifier
        opacity: Fill opacity (0-1)
    """
    # Reproject to WGS84 for Folium
    gdf_wgs = gdf.to_crs("EPSG:4326") if gdf.crs and str(gdf.crs) != "EPSG:4326" else gdf.copy()

    color = LAYER_COLORS.get(layer_name, LAYER_COLORS["default"])
    display_name = LAYER_DISPLAY_NAMES.get(layer_name, f"📍 {layer_name.replace('_', ' ').title()}")

    feature_group = FeatureGroup(name=display_name)

    # Determine geometry type for styling
    geom_types = gdf_wgs.geometry.geom_type.unique()
    is_line = any(t in ["LineString", "MultiLineString"] for t in geom_types)
    is_point = any(t in ["Point", "MultiPoint"] for t in geom_types)

    if is_point:
        style = {
            "radius": 5,
            "color": color,
            "fill": True,
            "fillColor": color,
            "fillOpacity": opacity,
        }
    elif is_line:
        style = {
            "color": color,
            "weight": 2.5,
            "opacity": 0.9,
        }
    else:
        style = {
            "fillColor": color,
            "color": _darken_color(color),
            "weight": 1,
            "fillOpacity": opacity * 0.8,
            "opacity": 0.9,
        }

    # Build tooltip fields
    tooltip_fields = [c for c in gdf_wgs.columns if c != "geometry"][:4]
    tooltip_aliases = [f"{f.replace('_', ' ').title()}:" for f in tooltip_fields]

    tooltip = GeoJsonTooltip(
        fields=tooltip_fields,
        aliases=tooltip_aliases,
        localize=True,
        sticky=False,
    ) if tooltip_fields else None

    geojson_data = json.loads(gdf_wgs.to_json())

    GeoJson(
        geojson_data,
        style_function=lambda x, s=style: s,
        tooltip=tooltip,
        name=display_name,
    ).add_to(feature_group)

    feature_group.add_to(m)


def _darken_color(hex_color: str, factor: float = 0.7) -> str:
    """Darken a hex color by a factor."""
    try:
        hex_color = hex_color.lstrip("#")
        r, g, b = [int(hex_color[i:i+2], 16) / 255.0 for i in (0, 2, 4)]
        h, s, v = colorsys.rgb_to_hsv(r, g, b)
        v = v * factor
        r2, g2, b2 = colorsys.hsv_to_rgb(h, s, v)
        return f"#{int(r2*255):02x}{int(g2*255):02x}{int(b2*255):02x}"
    except Exception:
        return hex_color


def save_map(m: folium.Map, file_path: str) -> str:
    """
    Save Folium map to HTML file.

    Args:
        m: Folium Map object
        file_path: Output HTML file path

    Returns:
        File path of saved map
    """
    Path(file_path).parent.mkdir(parents=True, exist_ok=True)
    m.save(file_path)
    logger.info(f"Map saved: {file_path}")
    return file_path


def create_raster_preview(raster: dict, colormap: str = "terrain") -> Optional[np.ndarray]:
    """
    Create a preview image for a raster dataset.

    Args:
        raster: Raster dict from dataset_loader
        colormap: Matplotlib colormap name

    Returns:
        RGBA numpy array (H x W x 4), or None if failed
    """
    try:
        import matplotlib.pyplot as plt
        import matplotlib.cm as cm
        import matplotlib.colors as mcolors

        data = raster["data"][0]
        nodata = raster.get("nodata", -9999)

        masked = np.where(data == nodata, np.nan, data)

        vmin = np.nanpercentile(masked, 2)
        vmax = np.nanpercentile(masked, 98)

        norm = mcolors.Normalize(vmin=vmin, vmax=vmax)
        cmap_fn = cm.get_cmap(colormap)

        rgba = cmap_fn(norm(masked))
        rgba = (rgba * 255).astype(np.uint8)

        return rgba

    except Exception as e:
        logger.warning(f"Could not create raster preview: {e}")
        return None


def generate_statistics_html(workflow: dict) -> str:
    """
    Generate an HTML statistics panel for workflow results.

    Args:
        workflow: Executed workflow dictionary

    Returns:
        HTML string for statistics display
    """
    stats = workflow.get("statistics", {})
    outputs = workflow.get("outputs", {})

    # Compute output stats
    output_stats = []
    for layer_name, data in outputs.items():
        if isinstance(data, gpd.GeoDataFrame) and len(data) > 0:
            try:
                gdf_m = data.to_crs("EPSG:32646" if data.crs and data.crs.is_geographic else data.crs)
                total_area = gdf_m.geometry.area.sum() / 1_000_000
                output_stats.append({
                    "layer": layer_name.replace("_", " ").title(),
                    "features": len(data),
                    "area_km2": f"{total_area:.2f}",
                    "geom_type": data.geometry.geom_type.mode()[0],
                })
            except Exception:
                output_stats.append({
                    "layer": layer_name.replace("_", " ").title(),
                    "features": len(data),
                    "area_km2": "N/A",
                    "geom_type": "Mixed",
                })

    html = f"""
    <div style="font-family: 'Courier New', monospace; background: #0d1117; color: #c9d1d9; padding: 16px; border-radius: 8px;">
        <h4 style="color: #58a6ff; margin-top: 0;">📊 Workflow Execution Summary</h4>
        <table style="width:100%; border-collapse: collapse;">
            <tr><td style="color:#8b949e;">Total Steps</td><td style="color:#fff;">{stats.get('total_steps', '?')}</td></tr>
            <tr><td style="color:#8b949e;">Completed</td><td style="color:#3fb950;">✓ {stats.get('completed', 0)}</td></tr>
            <tr><td style="color:#8b949e;">Failed</td><td style="color:#f85149;">✗ {stats.get('failed', 0)}</td></tr>
            <tr><td style="color:#8b949e;">Layers Produced</td><td style="color:#fff;">{len(output_stats)}</td></tr>
        </table>
        <hr style="border-color: #30363d; margin: 12px 0;">
        <h5 style="color:#58a6ff; margin-bottom: 8px;">Output Layers</h5>
    """

    for stat in output_stats:
        html += f"""
        <div style="background:#161b22; padding:8px; border-radius:4px; margin-bottom:6px; border-left:3px solid #58a6ff;">
            <strong style="color:#f0f6fc;">{stat['layer']}</strong><br>
            <span style="color:#8b949e; font-size:0.85em;">
                {stat['features']} features | {stat['area_km2']} km² | {stat['geom_type']}
            </span>
        </div>
        """

    html += "</div>"
    return html


if __name__ == "__main__":
    # Test visualization
    from dataset_loader import _generate_synthetic_osm

    layers = {
        "rivers": _generate_synthetic_osm("rivers", "Assam, India"),
        "forests": _generate_synthetic_osm("forests", "Assam, India"),
    }

    m = create_folium_map(layers, center=(26.2, 92.9))
    save_map(m, "test_map.html")
    print("Map saved to test_map.html")
