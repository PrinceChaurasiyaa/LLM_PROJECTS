"""
llm_engine.py
=============
LLM Reasoning Engine with Chain-of-Thought prompting for geospatial tasks.

Supports multiple backends:
  - Ollama (local LLaMA-3, Mistral-7B) — primary
  - Anthropic Claude API              — fallback
  - OpenAI GPT API                    — fallback

Author: GeoSpatial LLM System
"""

import os
import json
import re
from typing import Optional, Generator
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential


# ── Prompt Templates ─────────────────────────────────────────────────────────

COT_SYSTEM_PROMPT = """You are an expert GIS analyst and geospatial systems architect.
Your role is to break down complex spatial analysis tasks into logical, executable steps
using Chain-of-Thought reasoning.

You have access to the following GIS tools:
{tool_list}

When given a geospatial query, you must:
1. UNDERSTAND the spatial problem
2. IDENTIFY required datasets and data sources
3. REASON step-by-step about the GIS workflow
4. SELECT appropriate tools from the registry
5. OUTPUT a structured JSON workflow

Always think explicitly before acting. Show your reasoning.
Be specific about coordinate reference systems (CRS), data types, and parameters.
"""

COT_REASONING_PROMPT = """
=== GEOSPATIAL CHAIN-OF-THOUGHT REASONING ===

User Query: {query}

Relevant GIS Documentation Context:
{rag_context}

Please reason through this problem step-by-step:

STEP 1 - UNDERSTAND THE TASK:
What is the spatial analysis goal? What are the key geographic entities involved?

STEP 2 - IDENTIFY DATASETS:
What input datasets are needed? (DEM, OSM layers, shapefiles, etc.)
What spatial extent / study area? What CRS should be used?

STEP 3 - PLAN THE WORKFLOW:
List each GIS operation in logical order. Explain WHY each step is needed.
Consider: data loading → preprocessing → analysis → output

STEP 4 - SELECT TOOLS:
For each step, identify the specific GIS tool from the registry.
Specify input/output data flows between steps.

STEP 5 - IDENTIFY POTENTIAL ISSUES:
CRS mismatches? Missing data? Geometry errors? Edge cases?

STEP 6 - GENERATE WORKFLOW JSON:
Based on your reasoning, output the final workflow as valid JSON:

```json
{{
  "workflow_id": "auto-generated",
  "query": "{query}",
  "study_area": "<identified location>",
  "estimated_crs": "<recommended EPSG code>",
  "steps": [
    {{
      "step_id": 1,
      "name": "<step name>",
      "tool": "<tool_name>",
      "description": "<what this step does>",
      "inputs": {{}},
      "output_layer": "<layer name>",
      "reasoning": "<why this step is needed>"
    }}
  ],
  "expected_outputs": ["<list of output files>"],
  "notes": "<any important notes>"
}}
```
"""

VALIDATION_PROMPT = """
Review this GIS workflow JSON for logical correctness:

{workflow_json}

Check:
1. Are the steps in logical order?
2. Do tool inputs match previous step outputs?
3. Are there any missing steps?
4. Is the CRS handling correct?

Return ONLY the corrected JSON workflow, no explanations.
"""


class LLMEngine:
    """
    Core LLM engine supporting Ollama, Anthropic, and OpenAI backends.
    Implements Chain-of-Thought reasoning for geospatial workflow generation.
    """

    def __init__(
        self,
        backend: str = "ollama",
        model: str = "llama3",
        temperature: float = 0.1,
        max_tokens: int = 4096,
        ollama_base_url: str = "http://localhost:11434",
    ):
        """
        Initialize the LLM engine.

        Args:
            backend: 'ollama', 'anthropic', or 'openai'
            model: Model identifier
            temperature: Sampling temperature (low = more deterministic)
            max_tokens: Maximum response tokens
            ollama_base_url: Ollama server URL
        """
        self.backend = backend
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.ollama_base_url = ollama_base_url
        self._client = None
        self._setup_client()
        logger.info(f"LLMEngine initialized | backend={backend} | model={model}")

    def _setup_client(self):
        """Initialize the appropriate LLM client."""
        if self.backend == "ollama":
            try:
                from langchain_ollama import OllamaLLM
                self._client = OllamaLLM(
                    model=self.model,
                    base_url=self.ollama_base_url,
                    temperature=self.temperature,
                )
                logger.info("Ollama client initialized")
            except Exception as e:
                logger.warning(f"Ollama setup failed: {e}. Will use direct HTTP.")
                self._client = None

        elif self.backend == "anthropic":
            try:
                import anthropic
                self._client = anthropic.Anthropic(
                    api_key=os.getenv("ANTHROPIC_API_KEY")
                )
                if not self.model.startswith("claude"):
                    self.model = "claude-sonnet-4-20250514"
                logger.info("Anthropic client initialized")
            except Exception as e:
                logger.error(f"Anthropic setup failed: {e}")
                raise

        elif self.backend == "openai":
            try:
                from openai import OpenAI
                self._client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
                if not self.model.startswith("gpt"):
                    self.model = "gpt-4o"
                logger.info("OpenAI client initialized")
            except Exception as e:
                logger.error(f"OpenAI setup failed: {e}")
                raise

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    def generate(self, prompt: str, system_prompt: str = "") -> str:
        """
        Generate a response from the LLM.

        Args:
            prompt: User prompt
            system_prompt: System/context prompt

        Returns:
            LLM response text
        """
        logger.debug(f"Generating response | backend={self.backend}")

        if self.backend == "ollama":
            return self._generate_ollama(prompt, system_prompt)
        elif self.backend == "anthropic":
            return self._generate_anthropic(prompt, system_prompt)
        elif self.backend == "openai":
            return self._generate_openai(prompt, system_prompt)
        else:
            raise ValueError(f"Unknown backend: {self.backend}")

    def _generate_ollama(self, prompt: str, system_prompt: str) -> str:
        """Generate using Ollama (local LLM)."""
        try:
            # Try LangChain Ollama first
            if self._client:
                from langchain_core.messages import HumanMessage, SystemMessage
                from langchain_ollama import ChatOllama
                chat = ChatOllama(
                    model=self.model,
                    base_url=self.ollama_base_url,
                    temperature=self.temperature,
                )
                messages = []
                if system_prompt:
                    messages.append(SystemMessage(content=system_prompt))
                messages.append(HumanMessage(content=prompt))
                response = chat.invoke(messages)
                return response.content

            # Fallback: direct HTTP to Ollama API
            import requests
            payload = {
                "model": self.model,
                "prompt": f"{system_prompt}\n\n{prompt}" if system_prompt else prompt,
                "stream": False,
                "options": {
                    "temperature": self.temperature,
                    "num_predict": self.max_tokens,
                }
            }
            resp = requests.post(
                f"{self.ollama_base_url}/api/generate",
                json=payload,
                timeout=120
            )
            resp.raise_for_status()
            return resp.json().get("response", "")

        except Exception as e:
            logger.error(f"Ollama generation failed: {e}")
            # Return a mock response for demo when Ollama is not running
            return self._mock_response(prompt)

    def _generate_anthropic(self, prompt: str, system_prompt: str) -> str:
        """Generate using Anthropic Claude API."""
        response = self._client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            system=system_prompt or "You are a helpful geospatial AI assistant.",
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text

    def _generate_openai(self, prompt: str, system_prompt: str) -> str:
        """Generate using OpenAI GPT API."""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        response = self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
        return response.choices[0].message.content

    def _mock_response(self, prompt: str) -> str:
        """
        Mock LLM response for demo/testing when no LLM is available.
        Detects query type and returns appropriate mock workflow.
        """
        prompt_lower = prompt.lower()

        if any(kw in prompt_lower for kw in ["flood", "river", "inundation", "water"]):
            return self._mock_flood_response()
        elif any(kw in prompt_lower for kw in ["solar", "suitability", "site", "farm"]):
            return self._mock_solar_response()
        elif any(kw in prompt_lower for kw in ["ndvi", "vegetation", "forest", "land cover"]):
            return self._mock_vegetation_response()
        else:
            return self._mock_generic_response()

    def _mock_flood_response(self) -> str:
        return """
STEP 1 - UNDERSTAND THE TASK:
The goal is to identify areas at risk of flooding near rivers. This involves DEM analysis for low-elevation zones and proximity analysis to river networks.

STEP 2 - IDENTIFY DATASETS:
- DEM (Digital Elevation Model): 30m SRTM or ALOS data
- River network: OSM waterways layer
- Study area: Administrative boundary
- Target CRS: UTM Zone 46N (EPSG:32646) for metric calculations

STEP 3 - PLAN THE WORKFLOW:
1. Load DEM raster for elevation data
2. Threshold DEM to find low-elevation zones (< 50m)
3. Convert low-elevation raster to vector polygons
4. Load river network from OSM
5. Buffer rivers by 1km to capture flood-prone corridor
6. Intersect low-elevation zones with river buffers
7. Calculate area statistics for flood risk zones

STEP 4 - SELECT TOOLS:
Each step maps to registry tools: load_raster → raster_threshold → raster_to_vector → load_osm → buffer → overlay → calculate_area

STEP 5 - IDENTIFY POTENTIAL ISSUES:
CRS mismatch between DEM (WGS84) and analysis (UTM). Geometry validity after raster vectorization.

STEP 6 - GENERATE WORKFLOW JSON:
```json
{
  "workflow_id": "flood_risk_001",
  "query": "Find flood-prone areas near rivers",
  "study_area": "Assam, India",
  "estimated_crs": "EPSG:32646",
  "steps": [
    {
      "step_id": 1,
      "name": "Load DEM",
      "tool": "load_raster",
      "description": "Load Digital Elevation Model for terrain analysis",
      "inputs": {"source": "srtm_dem", "band": 1},
      "output_layer": "dem_raw",
      "reasoning": "DEM is required to identify low-lying areas susceptible to flooding"
    },
    {
      "step_id": 2,
      "name": "Reproject DEM to UTM",
      "tool": "reproject",
      "description": "Reproject raster to metric CRS for accurate distance calculations",
      "inputs": {"dataset": "dem_raw", "target_crs": "EPSG:32646"},
      "output_layer": "dem_utm",
      "reasoning": "Metric CRS required for accurate area and distance computations"
    },
    {
      "step_id": 3,
      "name": "Identify Low Elevation Areas",
      "tool": "raster_threshold",
      "description": "Threshold DEM to extract pixels below 50m elevation",
      "inputs": {"raster": "dem_utm", "operator": "<", "threshold_value": 50},
      "output_layer": "low_elev_raster",
      "reasoning": "Low elevation areas are more susceptible to flooding"
    },
    {
      "step_id": 4,
      "name": "Vectorize Low Elevation Zones",
      "tool": "raster_to_vector",
      "description": "Convert binary raster mask to vector polygons",
      "inputs": {"binary_raster": "low_elev_raster"},
      "output_layer": "low_elev_zones",
      "reasoning": "Vector format needed for spatial overlay with river buffers"
    },
    {
      "step_id": 5,
      "name": "Load River Network",
      "tool": "load_osm",
      "description": "Load river and waterway data from OpenStreetMap",
      "inputs": {"place_name": "Assam, India", "feature_type": "waterways"},
      "output_layer": "rivers_raw",
      "reasoning": "River proximity is a primary factor in flood risk assessment"
    },
    {
      "step_id": 6,
      "name": "Buffer Rivers",
      "tool": "buffer",
      "description": "Create 1000m buffer around river lines to define flood corridor",
      "inputs": {"geometry": "rivers_raw", "distance_meters": 1000},
      "output_layer": "river_buffer",
      "reasoning": "1km buffer captures immediate flood-prone corridor around rivers"
    },
    {
      "step_id": 7,
      "name": "Overlay Flood Risk Zones",
      "tool": "overlay",
      "description": "Intersect low-elevation zones with river buffers",
      "inputs": {"geodataframe1": "low_elev_zones", "geodataframe2": "river_buffer", "how": "intersection"},
      "output_layer": "flood_risk_zones",
      "reasoning": "Areas that are BOTH low-elevation AND near rivers have highest flood risk"
    },
    {
      "step_id": 8,
      "name": "Calculate Flood Risk Area",
      "tool": "calculate_area",
      "description": "Compute total area of flood-prone zones in km²",
      "inputs": {"geodataframe": "flood_risk_zones"},
      "output_layer": "flood_risk_final",
      "reasoning": "Area statistics quantify the extent of flood risk"
    }
  ],
  "expected_outputs": ["flood_risk_zones.geojson", "flood_risk_statistics.json", "flood_risk_map.html"],
  "notes": "Buffer distance can be adjusted based on river size. Consider seasonal variation in flood risk."
}
```
"""

    def _mock_solar_response(self) -> str:
        return """
STEP 1 - UNDERSTAND THE TASK:
Identify suitable locations for solar farm installation. Key criteria: flat terrain, no forests, no water bodies, proximity to roads for maintenance access.

STEP 2 - IDENTIFY DATASETS:
- DEM for slope analysis
- OSM landuse layer (forests, water bodies)
- OSM roads network
- Administrative boundary for study area
- Target CRS: UTM Zone 44N (EPSG:32644)

STEP 3 - PLAN THE WORKFLOW:
1. Load DEM and compute slope
2. Filter flat areas (slope < 5°)
3. Load OSM landuse — exclude forests and water
4. Load roads and create access buffer
5. Combine suitability criteria using overlay

STEP 6 - GENERATE WORKFLOW JSON:
```json
{
  "workflow_id": "solar_suitability_001",
  "query": "Find suitable locations for solar farms",
  "study_area": "Rajasthan, India",
  "estimated_crs": "EPSG:32644",
  "steps": [
    {
      "step_id": 1,
      "name": "Load DEM",
      "tool": "load_raster",
      "description": "Load elevation model for terrain analysis",
      "inputs": {"source": "srtm_dem", "band": 1},
      "output_layer": "dem_raw",
      "reasoning": "Terrain analysis needed to find flat areas suitable for solar panels"
    },
    {
      "step_id": 2,
      "name": "Calculate Slope",
      "tool": "calculate_slope",
      "description": "Derive slope raster from DEM in degrees",
      "inputs": {"dem_raster": "dem_raw"},
      "output_layer": "slope_raster",
      "reasoning": "Solar farms require gentle slopes (< 5°) for optimal panel efficiency"
    },
    {
      "step_id": 3,
      "name": "Extract Flat Areas",
      "tool": "raster_threshold",
      "description": "Identify areas with slope < 5 degrees",
      "inputs": {"raster": "slope_raster", "operator": "<", "threshold_value": 5},
      "output_layer": "flat_areas_raster",
      "reasoning": "Slopes above 5° significantly reduce solar panel efficiency"
    },
    {
      "step_id": 4,
      "name": "Vectorize Flat Areas",
      "tool": "raster_to_vector",
      "description": "Convert flat area raster to vector polygons",
      "inputs": {"binary_raster": "flat_areas_raster"},
      "output_layer": "flat_areas_vector",
      "reasoning": "Vector needed for overlay with exclusion zones"
    },
    {
      "step_id": 5,
      "name": "Load Land Use",
      "tool": "load_osm",
      "description": "Load landuse layer including forests and water bodies",
      "inputs": {"place_name": "Rajasthan, India", "feature_type": "landuse"},
      "output_layer": "landuse_raw",
      "reasoning": "Forests and water bodies must be excluded from solar farm locations"
    },
    {
      "step_id": 6,
      "name": "Filter Exclusion Zones",
      "tool": "filter_by_attribute",
      "description": "Extract forests and water bodies for exclusion",
      "inputs": {"geodataframe": "landuse_raw", "column": "landuse", "operator": "contains", "value": "forest"},
      "output_layer": "exclusion_zones",
      "reasoning": "Environmental and practical constraints require excluding sensitive areas"
    },
    {
      "step_id": 7,
      "name": "Load Road Network",
      "tool": "load_osm",
      "description": "Load major roads for accessibility analysis",
      "inputs": {"place_name": "Rajasthan, India", "feature_type": "roads"},
      "output_layer": "roads_raw",
      "reasoning": "Solar farms need road access for construction and maintenance"
    },
    {
      "step_id": 8,
      "name": "Buffer Roads",
      "tool": "buffer",
      "description": "Create 2km buffer around major roads",
      "inputs": {"geometry": "roads_raw", "distance_meters": 2000},
      "output_layer": "road_buffer",
      "reasoning": "Sites must be within 2km of roads for practical accessibility"
    },
    {
      "step_id": 9,
      "name": "Compute Suitable Sites",
      "tool": "overlay",
      "description": "Intersect flat areas with road buffer, minus exclusion zones",
      "inputs": {"geodataframe1": "flat_areas_vector", "geodataframe2": "road_buffer", "how": "intersection"},
      "output_layer": "candidate_sites",
      "reasoning": "Suitable sites must satisfy all criteria simultaneously"
    },
    {
      "step_id": 10,
      "name": "Remove Exclusion Areas",
      "tool": "overlay",
      "description": "Subtract exclusion zones from candidate sites",
      "inputs": {"geodataframe1": "candidate_sites", "geodataframe2": "exclusion_zones", "how": "difference"},
      "output_layer": "solar_suitable_zones",
      "reasoning": "Final suitability requires removing all exclusion areas"
    }
  ],
  "expected_outputs": ["solar_suitable_zones.geojson", "suitability_report.json", "suitability_map.html"],
  "notes": "Consider adding solar irradiance data for more accurate suitability scoring."
}
```
"""

    def _mock_vegetation_response(self) -> str:
        return """
STEP 1 - UNDERSTAND THE TASK:
Monitor vegetation health and density using NDVI derived from multispectral satellite imagery.

STEP 6 - GENERATE WORKFLOW JSON:
```json
{
  "workflow_id": "ndvi_analysis_001",
  "query": "Analyze vegetation cover and health",
  "study_area": "User defined area",
  "estimated_crs": "EPSG:32644",
  "steps": [
    {"step_id": 1, "name": "Load NIR Band", "tool": "load_raster", "description": "Load near-infrared band", "inputs": {"source": "satellite_nir"}, "output_layer": "nir_band", "reasoning": "NIR band required for NDVI calculation"},
    {"step_id": 2, "name": "Load Red Band", "tool": "load_raster", "description": "Load red band", "inputs": {"source": "satellite_red"}, "output_layer": "red_band", "reasoning": "Red band required for NDVI calculation"},
    {"step_id": 3, "name": "Calculate NDVI", "tool": "calculate_ndvi", "description": "Compute NDVI from NIR and Red bands", "inputs": {"nir_band": "nir_band", "red_band": "red_band"}, "output_layer": "ndvi_raster", "reasoning": "NDVI quantifies vegetation density and health"},
    {"step_id": 4, "name": "Classify Vegetation", "tool": "raster_threshold", "description": "Classify NDVI into vegetation categories", "inputs": {"raster": "ndvi_raster", "operator": ">", "threshold_value": 0.3}, "output_layer": "vegetation_mask", "reasoning": "NDVI > 0.3 indicates healthy vegetation"},
    {"step_id": 5, "name": "Vectorize Results", "tool": "raster_to_vector", "description": "Convert vegetation mask to polygons", "inputs": {"binary_raster": "vegetation_mask"}, "output_layer": "vegetation_zones", "reasoning": "Vector format for area statistics and mapping"}
  ],
  "expected_outputs": ["vegetation_zones.geojson", "ndvi_statistics.json", "vegetation_map.html"]
}
```
"""

    def _mock_generic_response(self) -> str:
        return """
STEP 1 - UNDERSTAND THE TASK:
Performing spatial analysis based on the query. Will load relevant datasets and apply appropriate GIS operations.

STEP 6 - GENERATE WORKFLOW JSON:
```json
{
  "workflow_id": "spatial_analysis_001",
  "query": "Generic spatial analysis",
  "study_area": "User defined area",
  "estimated_crs": "EPSG:4326",
  "steps": [
    {"step_id": 1, "name": "Load Vector Data", "tool": "load_osm", "description": "Load relevant features from OSM", "inputs": {"place_name": "study area", "feature_type": "buildings"}, "output_layer": "input_features", "reasoning": "Initial data loading required for analysis"},
    {"step_id": 2, "name": "Spatial Analysis", "tool": "buffer", "description": "Apply buffer analysis", "inputs": {"geometry": "input_features", "distance_meters": 500}, "output_layer": "analysis_result", "reasoning": "Buffer analysis captures proximity relationships"},
    {"step_id": 3, "name": "Calculate Statistics", "tool": "calculate_area", "description": "Compute area statistics", "inputs": {"geodataframe": "analysis_result"}, "output_layer": "final_output", "reasoning": "Statistics summarize the analysis results"}
  ],
  "expected_outputs": ["analysis_result.geojson", "statistics.json", "result_map.html"]
}
```
"""

    def reason_and_plan(
        self,
        query: str,
        rag_context: str = "",
        tool_list: str = "",
    ) -> tuple[str, dict]:
        """
        Main method: Run CoT reasoning and return (reasoning_text, workflow_dict).

        Args:
            query: Natural language geospatial query
            rag_context: Retrieved documentation context from RAG
            tool_list: JSON string of available tools

        Returns:
            Tuple of (chain_of_thought_text, workflow_dict)
        """
        logger.info(f"Starting CoT reasoning for query: {query[:80]}...")

        # Build system prompt with tool list
        system = COT_SYSTEM_PROMPT.format(
            tool_list=tool_list or "See tool registry for available tools"
        )

        # Build reasoning prompt
        prompt = COT_REASONING_PROMPT.format(
            query=query,
            rag_context=rag_context or "No additional context retrieved.",
        )

        # Generate CoT reasoning
        raw_response = self.generate(prompt, system_prompt=system)
        logger.info("CoT reasoning generated successfully")

        # Extract JSON workflow from response
        workflow = self._extract_workflow_json(raw_response)

        return raw_response, workflow

    def _extract_workflow_json(self, text: str) -> dict:
        """
        Extract and parse JSON workflow from LLM response text.

        Handles:
        - JSON in code blocks (```json ... ```)
        - Raw JSON objects
        - Malformed JSON with basic repair
        """
        # Try extracting from code blocks first
        patterns = [
            r'```json\s*([\s\S]*?)\s*```',
            r'```\s*([\{][\s\S]*?)\s*```',
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                json_str = match.group(1).strip()
                try:
                    return json.loads(json_str)
                except json.JSONDecodeError:
                    # Try to repair common issues
                    json_str = self._repair_json(json_str)
                    try:
                        return json.loads(json_str)
                    except Exception:
                        continue

        # Try finding raw JSON object
        brace_match = re.search(r'\{[\s\S]*"steps"[\s\S]*\}', text)
        if brace_match:
            try:
                return json.loads(brace_match.group(0))
            except Exception:
                pass

        logger.warning("Could not extract JSON workflow from LLM response")
        return {"workflow_id": "parse_error", "steps": [], "error": "JSON extraction failed"}

    def _repair_json(self, json_str: str) -> str:
        """Attempt basic JSON repair for common LLM output issues."""
        # Remove trailing commas before } or ]
        json_str = re.sub(r',\s*([}\]])', r'\1', json_str)
        # Fix unquoted keys (basic)
        json_str = re.sub(r'(\w+)(?=\s*:)', r'"\1"', json_str)
        return json_str

    def validate_workflow(self, workflow: dict) -> tuple[bool, list[str]]:
        """
        Validate a generated workflow for logical correctness.

        Args:
            workflow: Workflow dictionary

        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []

        if "steps" not in workflow or not workflow["steps"]:
            issues.append("Workflow has no steps defined")
            return False, issues

        steps = workflow["steps"]
        output_layers = set()

        for i, step in enumerate(steps):
            # Check required fields
            for field in ["step_id", "name", "tool", "output_layer"]:
                if field not in step:
                    issues.append(f"Step {i+1} missing required field: {field}")

            # Track output layers
            if "output_layer" in step:
                output_layers.add(step["output_layer"])

        if not issues:
            logger.info(f"Workflow validation passed: {len(steps)} steps")
        else:
            logger.warning(f"Workflow validation found {len(issues)} issues")

        return len(issues) == 0, issues


def get_llm_engine(
    backend: str = "ollama",
    model: Optional[str] = None,
) -> LLMEngine:
    """
    Factory function to create LLM engine based on environment.

    Auto-detects available backends and falls back gracefully.
    """
    # Determine model
    if model is None:
        model_defaults = {
            "ollama": "llama3",
            "anthropic": "claude-sonnet-4-20250514",
            "openai": "gpt-4o",
        }
        model = model_defaults.get(backend, "llama3")

    return LLMEngine(backend=backend, model=model)


if __name__ == "__main__":
    # Quick test
    engine = get_llm_engine(backend="ollama", model="llama3")
    cot, workflow = engine.reason_and_plan(
        query="Find flood-prone areas near rivers in Assam, India"
    )
    print("=== Chain of Thought ===")
    print(cot[:500])
    print("\n=== Workflow Steps ===")
    for step in workflow.get("steps", []):
        print(f"  {step.get('step_id')}. {step.get('name')} → {step.get('tool')}")
