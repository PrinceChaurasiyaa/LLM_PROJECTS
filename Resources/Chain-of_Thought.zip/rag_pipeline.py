"""
rag_pipeline.py
===============
Retrieval-Augmented Generation (RAG) pipeline using FAISS vector store.

Loads GIS documentation, tool descriptions, and workflow examples
into a FAISS index. Retrieves relevant context for user queries to
ground LLM reasoning in accurate GIS knowledge.

Author: GeoSpatial LLM System
"""

import os
import json
import pickle
from pathlib import Path
from typing import Optional
from loguru import logger


# ── GIS Knowledge Base ────────────────────────────────────────────────────────

GIS_KNOWLEDGE_BASE = [
    # ── GeoPandas Documentation ──
    {
        "id": "geopandas_buffer",
        "source": "GeoPandas Docs",
        "category": "vector_operations",
        "content": """GeoPandas buffer() operation creates a geometry with a given buffer distance.
        Usage: gdf.geometry.buffer(distance, cap_style=1, join_style=1, resolution=16)
        Parameters:
        - distance: Buffer distance in CRS units (meters if projected, degrees if geographic)
        - cap_style: 1=round, 2=flat, 3=square
        - join_style: 1=round, 2=mitre, 3=bevel
        IMPORTANT: Always reproject to a metric CRS before buffering for accurate results.
        Example: rivers_utm = rivers.to_crs('EPSG:32646'); rivers_utm['geometry'] = rivers_utm.buffer(1000)"""
    },
    {
        "id": "geopandas_overlay",
        "source": "GeoPandas Docs",
        "category": "vector_operations",
        "content": """GeoPandas overlay() performs set-theory spatial operations between two GeoDataFrames.
        Usage: result = gpd.overlay(df1, df2, how='intersection')
        how options:
        - 'intersection': areas in both df1 and df2
        - 'union': all areas from df1 and df2
        - 'difference': areas in df1 NOT in df2
        - 'symmetric_difference': areas in df1 OR df2 but NOT both
        - 'identity': df1 unchanged but split where it intersects df2
        Both GeoDataFrames must have the same CRS before overlay.
        Example flood mapping: flood_risk = gpd.overlay(low_elevation, river_buffer, how='intersection')"""
    },
    {
        "id": "geopandas_spatial_join",
        "source": "GeoPandas Docs",
        "category": "vector_operations",
        "content": """GeoPandas spatial join (sjoin) joins attributes based on spatial relationship.
        Usage: result = gpd.sjoin(left_df, right_df, how='left', predicate='intersects')
        predicate options: 'intersects', 'contains', 'within', 'crosses', 'overlaps', 'touches'
        how options: 'left' (keep all left), 'right' (keep all right), 'inner' (only matches)
        Use for: finding points within polygons, assigning regions to features, proximity analysis."""
    },
    {
        "id": "geopandas_clip",
        "source": "GeoPandas Docs",
        "category": "vector_operations",
        "content": """GeoPandas clip() clips a GeoDataFrame to the bounds of a mask geometry.
        Usage: clipped = gpd.clip(gdf, mask)
        Both must be in same CRS. Returns only features within or intersecting the mask.
        Useful for: extracting features within a study area, cropping to administrative boundary.
        Example: study_area_rivers = gpd.clip(rivers, study_boundary)"""
    },
    # ── Rasterio Documentation ──
    {
        "id": "rasterio_open",
        "source": "Rasterio Docs",
        "category": "raster_operations",
        "content": """Rasterio: Open and read raster files (GeoTIFF, etc.)
        Usage:
        import rasterio
        with rasterio.open('dem.tif') as src:
            data = src.read(1)  # Read band 1
            profile = src.profile  # Metadata
            transform = src.transform  # Affine transform
            crs = src.crs  # Coordinate reference system
        Common profiles include: driver, dtype, nodata, width, height, count, crs, transform"""
    },
    {
        "id": "rasterio_slope",
        "source": "GDAL/Rasterio Docs",
        "category": "raster_operations",
        "content": """Slope calculation from DEM using numpy gradient:
        import numpy as np
        import rasterio
        with rasterio.open('dem.tif') as src:
            dem = src.read(1).astype(float)
            cellsize = src.res[0]  # pixel size in CRS units
        # Calculate gradient
        dy, dx = np.gradient(dem, cellsize)
        slope_rad = np.arctan(np.sqrt(dx**2 + dy**2))
        slope_deg = np.degrees(slope_rad)
        # slope_deg is now the slope in degrees
        Threshold for solar farms: slope < 5 degrees
        Threshold for flood risk: identify flat/low areas slope < 2 degrees"""
    },
    {
        "id": "rasterio_vectorize",
        "source": "Rasterio Docs",
        "category": "conversion",
        "content": """Convert raster to vector using rasterio.features.shapes():
        from rasterio.features import shapes
        from shapely.geometry import shape
        import geopandas as gpd
        
        with rasterio.open('binary_mask.tif') as src:
            mask_data = src.read(1)
            transform = src.transform
            crs = src.crs
        
        geoms = []
        for geom, val in shapes(mask_data.astype('uint8'), transform=transform):
            if val == 1:  # Only take masked pixels
                geoms.append(shape(geom))
        
        gdf = gpd.GeoDataFrame({'geometry': geoms}, crs=crs)"""
    },
    # ── Flood Risk Analysis ──
    {
        "id": "flood_risk_workflow",
        "source": "GIS Workflow Templates",
        "category": "workflow_templates",
        "content": """Standard Flood Risk Mapping Workflow:
        1. Load DEM (SRTM 30m recommended for regional analysis)
        2. Reproject to UTM for metric analysis
        3. Calculate slope - identify flat areas (< 2 degrees) prone to waterlogging
        4. Extract low elevation zones using threshold (e.g., < 50m MSL or percentile-based)
        5. Load river network from OSM (waterways: river, stream, canal)
        6. Buffer rivers: 500m for small rivers, 1000-2000m for major rivers
        7. Intersect low elevation zones with river buffers → flood risk zones
        8. Calculate affected areas and population (if data available)
        9. Classify risk: High (near river + low elev), Medium (low elev only), Low (rest)
        
        Key considerations:
        - Use local DEM (Bhoonidhi/Cartosat DEM preferred for India) for better accuracy
        - Consider monsoon season river flow patterns
        - Historical flood event data improves model validation"""
    },
    {
        "id": "site_suitability_workflow",
        "source": "GIS Workflow Templates",
        "category": "workflow_templates",
        "content": """Site Suitability Analysis - Multi-Criteria Evaluation (MCE):
        Standard criteria layers:
        - Slope: Derived from DEM (flat areas preferred for most uses)
        - Landuse/Landcover: Exclude sensitive areas (forest, water bodies, urban)
        - Proximity to roads: Buffer analysis for accessibility
        - Proximity to power grid: For energy projects
        - Soil type: For agriculture/construction
        
        Workflow:
        1. Prepare individual criteria rasters/vectors
        2. Normalize each criterion (0-1 scale)
        3. Apply weights using AHP or equal weighting
        4. Overlay using weighted sum
        5. Classify suitability zones (high/medium/low)
        6. Validate against ground truth or expert knowledge"""
    },
    # ── CRS and Projections ──
    {
        "id": "crs_india",
        "source": "Geospatial Reference",
        "category": "crs",
        "content": """Recommended CRS for India geospatial projects:
        - EPSG:4326 (WGS84): Geographic, use for data storage and web maps
        - EPSG:32644: UTM Zone 44N - covers western India (longitude 78-84°E)
        - EPSG:32645: UTM Zone 45N - covers central India (longitude 84-90°E)  
        - EPSG:32646: UTM Zone 46N - covers northeastern India including Assam (longitude 90-96°E)
        - EPSG:7755: India custom GRS80 ellipsoid
        
        CRS transformation in GeoPandas:
        gdf_utm = gdf.to_crs('EPSG:32646')  # Reproject to UTM for metric operations
        gdf_wgs = gdf_utm.to_crs('EPSG:4326')  # Back to geographic for storage
        
        Always check CRS before spatial operations:
        assert gdf1.crs == gdf2.crs, f"CRS mismatch: {gdf1.crs} vs {gdf2.crs}"""
    },
    # ── OSM Data ──
    {
        "id": "osmnx_usage",
        "source": "OSMnx Documentation",
        "category": "data_sources",
        "content": """Loading data from OpenStreetMap using OSMnx:
        import osmnx as ox
        
        # Get features by place name
        rivers = ox.features_from_place('Assam, India', tags={'waterway': True})
        roads = ox.features_from_place('Assam, India', tags={'highway': ['primary', 'secondary']})
        landuse = ox.features_from_place('Assam, India', tags={'landuse': True})
        buildings = ox.features_from_place('Assam, India', tags={'building': True})
        forests = ox.features_from_place('Assam, India', tags={'landuse': 'forest'})
        
        # Get features by bounding box [north, south, east, west]
        gdf = ox.features_from_bbox(26.5, 26.0, 93.0, 92.5, tags={'waterway': True})
        
        Returns GeoDataFrame with geometry and OSM attribute columns."""
    },
    {
        "id": "dem_sources",
        "source": "Geospatial Data Guide",
        "category": "data_sources",
        "content": """DEM Data Sources for India:
        1. SRTM (Shuttle Radar Topography Mission): 30m resolution, global, free
           - Download: https://earthexplorer.usgs.gov/ or NASA EarthData
           - CRS: WGS84 (EPSG:4326)
        
        2. Bhoonidhi (ISRO): High-resolution Cartosat DEM, 10m for India
           - Register at: https://bhoonidhi.nrsc.gov.in/
           - Better accuracy for Indian terrain
        
        3. ALOS World 3D (AW3D30): 30m global DEM, good accuracy
           - Free download from JAXA
        
        4. MERIT DEM: Improved 90m DEM, good for hydrological analysis
        
        For flood analysis: Use Cartosat DEM (10m) or SRTM (30m) minimum.
        For regional analysis: SRTM 90m may suffice."""
    },
    # ── NDVI ──
    {
        "id": "ndvi_calculation",
        "source": "Remote Sensing Reference",
        "category": "raster_operations",
        "content": """NDVI (Normalized Difference Vegetation Index) Calculation:
        Formula: NDVI = (NIR - Red) / (NIR + Red)
        Range: -1 to +1
        Interpretation:
        - < 0: Water, snow, clouds, bare rock
        - 0.0 to 0.1: Bare soil, sand
        - 0.1 to 0.2: Sparse vegetation, shrubs
        - 0.2 to 0.4: Moderate vegetation (grassland, crops)
        - 0.4 to 0.6: Dense vegetation
        - > 0.6: Very dense/healthy forest
        
        Sentinel-2 bands: NIR = Band 8 (842nm), Red = Band 4 (665nm)
        Landsat 8/9 bands: NIR = Band 5, Red = Band 4
        
        import numpy as np
        ndvi = np.where((nir + red) == 0, 0, (nir.astype(float) - red.astype(float)) / (nir.astype(float) + red.astype(float)))"""
    },
]


class RAGPipeline:
    """
    Retrieval-Augmented Generation pipeline using FAISS for GIS documentation.

    Embeds GIS documentation chunks into a FAISS index and retrieves
    relevant context for user queries to ground LLM reasoning.
    """

    def __init__(
        self,
        knowledge_base_path: str = "knowledge_base",
        embedding_model: str = "all-MiniLM-L6-v2",
        index_path: Optional[str] = None,
    ):
        self.knowledge_base_path = Path(knowledge_base_path)
        self.knowledge_base_path.mkdir(exist_ok=True)
        self.embedding_model_name = embedding_model
        self.index_path = index_path or str(self.knowledge_base_path / "faiss_index.pkl")

        self._embedder = None
        self._index = None
        self._documents = []
        self._initialized = False

        logger.info(f"RAGPipeline created | embedding_model={embedding_model}")

    def _get_embedder(self):
        """Lazy-load sentence transformer embedder."""
        if self._embedder is None:
            try:
                from sentence_transformers import SentenceTransformer
                self._embedder = SentenceTransformer(self.embedding_model_name)
                logger.info(f"Loaded embedder: {self.embedding_model_name}")
            except ImportError:
                logger.warning("sentence-transformers not available. Using mock embedder.")
                self._embedder = "mock"
        return self._embedder

    def _embed(self, texts: list[str]) -> list:
        """Generate embeddings for a list of texts."""
        embedder = self._get_embedder()
        if embedder == "mock":
            import hashlib, struct
            # Deterministic mock embeddings
            embeddings = []
            for text in texts:
                h = hashlib.md5(text.encode()).digest()
                vec = [struct.unpack('f', h[i:i+4])[0] for i in range(0, min(16, len(h)), 4)]
                vec = (vec * 96)[:384]  # Pad to 384 dims
                embeddings.append(vec)
            return embeddings
        return embedder.encode(texts, show_progress_bar=False).tolist()

    def build_index(self, custom_documents: Optional[list[dict]] = None):
        """
        Build FAISS index from GIS knowledge base documents.

        Args:
            custom_documents: Additional documents to include beyond the default KB
        """
        documents = list(GIS_KNOWLEDGE_BASE)
        if custom_documents:
            documents.extend(custom_documents)

        # Load additional docs from knowledge_base directory
        for json_file in self.knowledge_base_path.glob("*.json"):
            try:
                with open(json_file) as f:
                    extra = json.load(f)
                    if isinstance(extra, list):
                        documents.extend(extra)
                logger.info(f"Loaded {len(extra)} docs from {json_file.name}")
            except Exception as e:
                logger.warning(f"Could not load {json_file}: {e}")

        self._documents = documents
        texts = [f"{doc['source']} | {doc['category']} | {doc['content']}" for doc in documents]

        logger.info(f"Building FAISS index with {len(texts)} documents...")
        embeddings = self._embed(texts)

        try:
            import faiss
            import numpy as np

            dim = len(embeddings[0])
            index = faiss.IndexFlatL2(dim)
            vectors = np.array(embeddings, dtype='float32')
            index.add(vectors)
            self._index = index
            logger.info(f"FAISS index built: {index.ntotal} vectors, dim={dim}")
        except ImportError:
            logger.warning("FAISS not available. Using simple cosine similarity fallback.")
            self._index = "simple"

        # Cache to disk
        self._save_index()
        self._initialized = True

    def _save_index(self):
        """Save index and documents to disk."""
        try:
            cache = {
                "documents": self._documents,
                "index_type": "faiss" if self._index != "simple" else "simple",
            }
            with open(self.index_path, "wb") as f:
                pickle.dump(cache, f)

            if self._index not in (None, "simple"):
                import faiss
                faiss.write_index(self._index, self.index_path + ".faiss")

            logger.info(f"Index saved to {self.index_path}")
        except Exception as e:
            logger.warning(f"Could not save index: {e}")

    def load_index(self) -> bool:
        """Load pre-built index from disk."""
        try:
            with open(self.index_path, "rb") as f:
                cache = pickle.load(f)
            self._documents = cache["documents"]

            if cache["index_type"] == "faiss":
                import faiss
                self._index = faiss.read_index(self.index_path + ".faiss")

            self._initialized = True
            logger.info(f"Loaded index: {len(self._documents)} documents")
            return True
        except Exception as e:
            logger.info(f"No cached index found, will rebuild: {e}")
            return False

    def retrieve(self, query: str, top_k: int = 4) -> list[dict]:
        """
        Retrieve most relevant documents for a query.

        Args:
            query: User query string
            top_k: Number of documents to retrieve

        Returns:
            List of relevant document dictionaries
        """
        if not self._initialized:
            if not self.load_index():
                self.build_index()

        if not self._documents:
            return []

        query_embedding = self._embed([query])[0]

        if self._index not in (None, "simple"):
            # FAISS retrieval
            import faiss, numpy as np
            q = np.array([query_embedding], dtype='float32')
            distances, indices = self._index.search(q, min(top_k, len(self._documents)))
            results = [self._documents[i] for i in indices[0] if i < len(self._documents)]
        else:
            # Simple cosine similarity fallback
            results = self._simple_retrieve(query, query_embedding, top_k)

        logger.debug(f"Retrieved {len(results)} docs for query: {query[:50]}...")
        return results

    def _simple_retrieve(self, query: str, query_emb: list, top_k: int) -> list[dict]:
        """Simple keyword + cosine similarity retrieval fallback."""
        import math

        # Score each document
        query_lower = query.lower()
        scores = []

        for i, doc in enumerate(self._documents):
            # Keyword score
            kw_score = sum(1 for w in query_lower.split() if w in doc["content"].lower())

            # Category match bonus
            cat_bonus = 0
            if "flood" in query_lower and "flood" in doc.get("category", ""):
                cat_bonus = 3
            if "slope" in query_lower and "slope" in doc["content"].lower():
                cat_bonus = 2
            if "solar" in query_lower and "suitability" in doc.get("content", "").lower():
                cat_bonus = 2

            scores.append((i, kw_score + cat_bonus))

        scores.sort(key=lambda x: x[1], reverse=True)
        return [self._documents[i] for i, _ in scores[:top_k]]

    def format_context(self, documents: list[dict], max_chars: int = 3000) -> str:
        """
        Format retrieved documents into a context string for LLM.

        Args:
            documents: List of retrieved documents
            max_chars: Maximum characters for context

        Returns:
            Formatted context string
        """
        if not documents:
            return "No relevant documentation found."

        parts = []
        total = 0
        for doc in documents:
            chunk = f"[{doc['source']} | {doc['category']}]\n{doc['content']}\n"
            if total + len(chunk) > max_chars:
                break
            parts.append(chunk)
            total += len(chunk)

        return "\n---\n".join(parts)

    def retrieve_and_format(self, query: str, top_k: int = 4) -> str:
        """Convenience method: retrieve + format in one call."""
        docs = self.retrieve(query, top_k=top_k)
        return self.format_context(docs)

    def add_workflow_example(self, query: str, workflow: dict):
        """
        Add a successful workflow to the knowledge base for future retrieval.

        Args:
            query: The original user query
            workflow: The executed workflow dictionary
        """
        doc = {
            "id": f"workflow_{workflow.get('workflow_id', 'unknown')}",
            "source": "Validated Workflow Examples",
            "category": "workflow_templates",
            "content": f"Query: {query}\nWorkflow: {json.dumps(workflow, indent=2)}"
        }

        # Add to in-memory documents
        self._documents.append(doc)

        # Persist to knowledge base directory
        examples_file = self.knowledge_base_path / "workflow_examples.json"
        existing = []
        if examples_file.exists():
            try:
                with open(examples_file) as f:
                    existing = json.load(f)
            except Exception:
                pass
        existing.append(doc)
        with open(examples_file, "w") as f:
            json.dump(existing, f, indent=2)

        logger.info(f"Added workflow example to knowledge base: {workflow.get('workflow_id')}")

        # Rebuild index
        self.build_index()


def get_tool_descriptions(tool_registry_path: str = "tool_registry.json") -> str:
    """
    Load tool registry and format as context string for LLM.

    Args:
        tool_registry_path: Path to tool_registry.json

    Returns:
        Formatted tool descriptions string
    """
    try:
        with open(tool_registry_path) as f:
            registry = json.load(f)

        lines = ["Available GIS Tools:"]
        for tool in registry.get("tools", []):
            lines.append(
                f"- {tool['tool']} [{tool['category']}]: {tool['description']} "
                f"| inputs: {tool['inputs']} | output: {tool['output']}"
            )
        return "\n".join(lines)
    except Exception as e:
        logger.warning(f"Could not load tool registry: {e}")
        return "Tool registry unavailable."


if __name__ == "__main__":
    # Test RAG pipeline
    rag = RAGPipeline(knowledge_base_path="knowledge_base")
    rag.build_index()

    query = "How do I identify flood-prone areas near rivers?"
    docs = rag.retrieve(query, top_k=3)
    print(f"Query: {query}")
    print(f"Retrieved {len(docs)} documents:")
    for doc in docs:
        print(f"  - [{doc['source']}] {doc['content'][:100]}...")
