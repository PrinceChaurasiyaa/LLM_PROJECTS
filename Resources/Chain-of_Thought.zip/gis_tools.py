"""
gis_tools.py
============
GIS Execution Engine implementing all tool registry operations.

Implements:
  - Vector operations: buffer, clip, spatial join, overlay, dissolve, filter
  - Raster operations: slope, aspect, NDVI, threshold, vectorize
  - CRS operations: reproject, validate
  - Analysis: area calculation, statistics
  - Conversion: raster-to-vector, vector-to-raster

All operations include:
  - CRS mismatch handling
  - Geometry validation
  - Error recovery
  - Detailed logging

Author: GeoSpatial LLM System
"""

import os
import json
import time
from pathlib import Path
from typing import Optional, Union
from loguru import logger

import numpy as np
import geopandas as gpd
from shapely.geometry import shape, mapping
from shapely.validation import make_valid
from pyproj import CRS, Transformer


# ── CRS Utilities ─────────────────────────────────────────────────────────────

def align_crs(gdf1: gpd.GeoDataFrame, gdf2: gpd.GeoDataFrame) -> tuple:
    """
    Ensure two GeoDataFrames share the same CRS.

    Strategy: reproject gdf2 to gdf1's CRS.

    Args:
        gdf1, gdf2: Input GeoDataFrames

    Returns:
        (gdf1, gdf2) with matching CRS
    """
    if gdf1.crs is None:
        gdf1 = gdf1.set_crs("EPSG:4326")
    if gdf2.crs is None:
        gdf2 = gdf2.set_crs("EPSG:4326")

    if gdf1.crs != gdf2.crs:
        logger.warning(f"CRS mismatch: {gdf1.crs.to_string()} vs {gdf2.crs.to_string()}. Reprojecting.")
        gdf2 = gdf2.to_crs(gdf1.crs)

    return gdf1, gdf2


def reproject(
    dataset: Union[gpd.GeoDataFrame, dict],
    target_crs: str,
) -> Union[gpd.GeoDataFrame, dict]:
    """
    Reproject vector or raster data to target CRS.

    Args:
        dataset: GeoDataFrame or raster dict
        target_crs: Target CRS string (e.g., 'EPSG:32646')

    Returns:
        Reprojected dataset
    """
    if isinstance(dataset, gpd.GeoDataFrame):
        source_crs = dataset.crs
        result = dataset.to_crs(target_crs)
        logger.info(f"Vector reprojected: {source_crs} → {target_crs}")
        return result

    elif isinstance(dataset, dict) and "data" in dataset:
        # Raster reprojection using rasterio.warp
        import rasterio
        from rasterio.warp import calculate_default_transform, reproject as rasterio_reproject, Resampling
        import io

        data = dataset["data"]
        src_crs = dataset["crs"]
        src_transform = dataset["transform"]
        h, w = dataset["shape"]

        dst_crs = CRS.from_string(target_crs)
        dst_transform, dst_width, dst_height = calculate_default_transform(
            src_crs, dst_crs, w, h, *dataset["bounds"]
        )

        out_array = np.zeros((dataset["bands"], dst_height, dst_width), dtype=data.dtype)

        for band_idx in range(dataset["bands"]):
            rasterio_reproject(
                source=data[band_idx],
                destination=out_array[band_idx],
                src_transform=src_transform,
                src_crs=src_crs,
                dst_transform=dst_transform,
                dst_crs=dst_crs,
                resampling=Resampling.bilinear,
            )

        profile = dataset["profile"].copy()
        profile.update({
            "crs": dst_crs,
            "transform": dst_transform,
            "width": dst_width,
            "height": dst_height,
        })

        logger.info(f"Raster reprojected: {src_crs} → {target_crs}")
        return {
            **dataset,
            "data": out_array,
            "profile": profile,
            "transform": dst_transform,
            "crs": dst_crs,
            "shape": (dst_height, dst_width),
        }

    else:
        raise TypeError(f"Cannot reproject type: {type(dataset)}")


# ── Vector Operations ─────────────────────────────────────────────────────────

def buffer(
    gdf: gpd.GeoDataFrame,
    distance_meters: float,
    cap_style: int = 1,
    join_style: int = 1,
) -> gpd.GeoDataFrame:
    """
    Create buffer zones around geometries.

    Automatically reprojects to metric UTM CRS for accurate buffering,
    then reprojects back to original CRS.

    Args:
        gdf: Input GeoDataFrame
        distance_meters: Buffer distance in meters
        cap_style: 1=round, 2=flat, 3=square
        join_style: 1=round, 2=mitre, 3=bevel

    Returns:
        Buffered GeoDataFrame in original CRS
    """
    if gdf is None or len(gdf) == 0:
        logger.warning("Buffer called on empty GeoDataFrame")
        return gdf

    original_crs = gdf.crs or "EPSG:4326"

    # Determine metric UTM CRS from centroid
    centroid = gdf.to_crs("EPSG:4326").unary_union.centroid
    utm_epsg = _get_utm_epsg(centroid.y, centroid.x)

    gdf_utm = gdf.to_crs(utm_epsg)
    gdf_utm = gdf_utm.copy()
    gdf_utm["geometry"] = gdf_utm.geometry.buffer(
        distance_meters, cap_style=cap_style, join_style=join_style
    )

    # Repair any buffer artifacts
    gdf_utm["geometry"] = gdf_utm["geometry"].apply(
        lambda g: make_valid(g) if not g.is_valid else g
    )

    result = gdf_utm.to_crs(original_crs)
    logger.info(f"Buffered {len(gdf)} features by {distance_meters}m (UTM: {utm_epsg})")
    return result


def clip(
    target: gpd.GeoDataFrame,
    mask: gpd.GeoDataFrame,
) -> gpd.GeoDataFrame:
    """
    Clip vector data to a boundary mask.

    Args:
        target: GeoDataFrame to clip
        mask: Clip mask GeoDataFrame

    Returns:
        Clipped GeoDataFrame
    """
    target, mask = align_crs(target, mask)

    try:
        result = gpd.clip(target, mask)
        result = result.reset_index(drop=True)
        logger.info(f"Clipped {len(target)} → {len(result)} features")
        return result
    except Exception as e:
        logger.error(f"Clip failed: {e}")
        raise


def spatial_join(
    left: gpd.GeoDataFrame,
    right: gpd.GeoDataFrame,
    how: str = "left",
    predicate: str = "intersects",
) -> gpd.GeoDataFrame:
    """
    Spatial join of two GeoDataFrames.

    Args:
        left, right: Input GeoDataFrames
        how: Join type ('left', 'right', 'inner')
        predicate: Spatial relationship ('intersects', 'contains', 'within', etc.)

    Returns:
        Joined GeoDataFrame
    """
    left, right = align_crs(left, right)

    result = gpd.sjoin(left, right, how=how, predicate=predicate)
    result = result.reset_index(drop=True)
    logger.info(f"Spatial join: {len(left)} x {len(right)} → {len(result)} features | {how}/{predicate}")
    return result


def overlay(
    gdf1: gpd.GeoDataFrame,
    gdf2: gpd.GeoDataFrame,
    how: str = "intersection",
) -> gpd.GeoDataFrame:
    """
    Overlay two GeoDataFrames using set-theory operations.

    Args:
        gdf1, gdf2: Input GeoDataFrames
        how: Operation type ('intersection', 'union', 'difference',
             'symmetric_difference', 'identity')

    Returns:
        Overlaid GeoDataFrame
    """
    gdf1, gdf2 = align_crs(gdf1, gdf2)

    # Fix geometries before overlay
    gdf1 = gdf1.copy()
    gdf2 = gdf2.copy()
    gdf1["geometry"] = gdf1.geometry.apply(lambda g: make_valid(g) if not g.is_valid else g)
    gdf2["geometry"] = gdf2.geometry.apply(lambda g: make_valid(g) if not g.is_valid else g)

    try:
        result = gpd.overlay(gdf1, gdf2, how=how, keep_geom_type=False)
        result = result[~result.geometry.is_empty].reset_index(drop=True)
        logger.info(f"Overlay ({how}): {len(gdf1)} + {len(gdf2)} → {len(result)} features")
        return result
    except Exception as e:
        logger.error(f"Overlay failed: {e}")
        raise


def dissolve(
    gdf: gpd.GeoDataFrame,
    by: str,
    aggfunc: str = "first",
) -> gpd.GeoDataFrame:
    """
    Dissolve geometries by a column.

    Args:
        gdf: Input GeoDataFrame
        by: Column to dissolve by
        aggfunc: Aggregation function for non-geometry columns

    Returns:
        Dissolved GeoDataFrame
    """
    if by not in gdf.columns:
        logger.warning(f"Column '{by}' not found. Dissolving all to single feature.")
        return gdf.dissolve()

    result = gdf.dissolve(by=by, aggfunc=aggfunc).reset_index()
    logger.info(f"Dissolved {len(gdf)} → {len(result)} features by '{by}'")
    return result


def filter_by_attribute(
    gdf: gpd.GeoDataFrame,
    column: str,
    operator: str,
    value,
) -> gpd.GeoDataFrame:
    """
    Filter GeoDataFrame rows by attribute condition.

    Args:
        gdf: Input GeoDataFrame
        column: Column name to filter on
        operator: Comparison operator ('==', '!=', '>', '<', '>=', '<=', 'contains', 'startswith')
        value: Value to compare against

    Returns:
        Filtered GeoDataFrame
    """
    if column not in gdf.columns:
        available = list(gdf.columns)
        logger.warning(f"Column '{column}' not found. Available: {available}")
        return gdf

    ops = {
        "==": lambda c, v: c == v,
        "!=": lambda c, v: c != v,
        ">": lambda c, v: c > v,
        "<": lambda c, v: c < v,
        ">=": lambda c, v: c >= v,
        "<=": lambda c, v: c <= v,
        "contains": lambda c, v: c.astype(str).str.contains(str(v), case=False, na=False),
        "startswith": lambda c, v: c.astype(str).str.startswith(str(v), na=False),
    }

    if operator not in ops:
        raise ValueError(f"Unknown operator: {operator}. Valid: {list(ops.keys())}")

    mask = ops[operator](gdf[column], value)
    result = gdf[mask].reset_index(drop=True)
    logger.info(f"Filter '{column}' {operator} '{value}': {len(gdf)} → {len(result)} features")
    return result


def calculate_area(
    gdf: gpd.GeoDataFrame,
    column_name: str = "area_km2",
) -> gpd.GeoDataFrame:
    """
    Calculate area of polygon features in km².

    Reprojects to metric UTM for accurate calculation.

    Args:
        gdf: Input GeoDataFrame
        column_name: Column name for area values

    Returns:
        GeoDataFrame with added area column
    """
    gdf = gdf.copy()
    centroid = gdf.to_crs("EPSG:4326").unary_union.centroid
    utm_epsg = _get_utm_epsg(centroid.y, centroid.x)

    gdf_utm = gdf.to_crs(utm_epsg)
    gdf[column_name] = gdf_utm.geometry.area / 1_000_000  # m² → km²

    total = gdf[column_name].sum()
    logger.info(f"Calculated areas: total={total:.2f} km², mean={gdf[column_name].mean():.4f} km²")
    return gdf


# ── Raster Operations ─────────────────────────────────────────────────────────

def calculate_slope(raster: dict) -> dict:
    """
    Calculate terrain slope in degrees from a DEM raster.

    Uses numpy gradient method (finite differences).

    Args:
        raster: Raster dict (from load_raster)

    Returns:
        Slope raster dict (values in degrees, 0-90)
    """
    dem = raster["data"][0].astype(float)
    transform = raster["transform"]

    # Handle nodata
    nodata = raster.get("nodata", -9999)
    if nodata is not None:
        dem = np.where(dem == nodata, np.nan, dem)

    # Cell size in CRS units
    cell_x = abs(transform.a)  # E-W resolution
    cell_y = abs(transform.e)  # N-S resolution

    # Convert degrees to meters if geographic CRS
    crs = raster.get("crs")
    if crs and hasattr(crs, "is_geographic") and crs.is_geographic:
        # Approximate: 1 degree ≈ 111,320m
        cell_x_m = cell_x * 111_320
        cell_y_m = cell_y * 111_320
    else:
        cell_x_m = cell_x
        cell_y_m = cell_y

    dy, dx = np.gradient(dem, cell_y_m, cell_x_m)
    slope_rad = np.arctan(np.sqrt(dx**2 + dy**2))
    slope_deg = np.degrees(slope_rad)

    # Fill NaN with -1
    slope_deg = np.where(np.isnan(slope_deg), -1, slope_deg)

    profile = raster["profile"].copy()
    profile.update({"dtype": "float32", "nodata": -1})

    logger.info(f"Slope calculated: min={slope_deg[slope_deg>0].min():.1f}°, max={slope_deg.max():.1f}°")

    return {
        **raster,
        "data": slope_deg[np.newaxis, :, :].astype(np.float32),
        "profile": profile,
        "type": "slope",
    }


def calculate_aspect(raster: dict) -> dict:
    """
    Calculate terrain aspect (0-360 degrees) from DEM.

    Args:
        raster: DEM raster dict

    Returns:
        Aspect raster dict (0=North, 90=East, 180=South, 270=West)
    """
    dem = raster["data"][0].astype(float)
    transform = raster["transform"]
    cell_size = abs(transform.a)

    dy, dx = np.gradient(dem, cell_size)
    aspect_rad = np.arctan2(-dx, dy)
    aspect_deg = np.degrees(aspect_rad)
    aspect_deg = (aspect_deg + 360) % 360

    profile = raster["profile"].copy()
    profile.update({"dtype": "float32", "nodata": -1})

    logger.info(f"Aspect calculated")
    return {**raster, "data": aspect_deg[np.newaxis, :, :].astype(np.float32), "profile": profile, "type": "aspect"}


def calculate_ndvi(nir_raster: dict, red_raster: dict) -> dict:
    """
    Calculate NDVI from NIR and Red band rasters.

    NDVI = (NIR - Red) / (NIR + Red)

    Args:
        nir_raster: Near-Infrared band raster dict
        red_raster: Red band raster dict

    Returns:
        NDVI raster dict (values -1 to +1)
    """
    nir = nir_raster["data"][0].astype(float)
    red = red_raster["data"][0].astype(float)

    # Avoid division by zero
    denom = nir + red
    ndvi = np.where(denom == 0, 0, (nir - red) / denom)
    ndvi = np.clip(ndvi, -1, 1).astype(np.float32)

    profile = nir_raster["profile"].copy()
    profile.update({"dtype": "float32", "nodata": -9999})

    mean_ndvi = np.mean(ndvi)
    veg_pct = (ndvi > 0.3).sum() / ndvi.size * 100
    logger.info(f"NDVI calculated: mean={mean_ndvi:.3f}, vegetation coverage={veg_pct:.1f}%")

    return {**nir_raster, "data": ndvi[np.newaxis, :, :], "profile": profile, "type": "ndvi"}


def raster_threshold(
    raster: dict,
    operator: str,
    threshold_value: float,
) -> dict:
    """
    Apply threshold to raster, creating binary mask.

    Args:
        raster: Input raster dict
        operator: Comparison operator ('<', '>', '<=', '>=', '==', '!=')
        threshold_value: Threshold value

    Returns:
        Binary raster dict (1=True, 0=False)
    """
    data = raster["data"][0].astype(float)

    ops = {
        "<": lambda d, v: d < v,
        ">": lambda d, v: d > v,
        "<=": lambda d, v: d <= v,
        ">=": lambda d, v: d >= v,
        "==": lambda d, v: d == v,
        "!=": lambda d, v: d != v,
    }

    if operator not in ops:
        raise ValueError(f"Unknown operator: {operator}")

    # Handle nodata
    nodata = raster.get("nodata", -9999)
    if nodata is not None:
        data = np.where(data == nodata, np.nan, data)

    binary = ops[operator](data, threshold_value).astype(np.uint8)
    binary = np.where(np.isnan(data), 0, binary)

    pct = binary.sum() / binary.size * 100
    profile = raster["profile"].copy()
    profile.update({"dtype": "uint8", "nodata": 0})

    logger.info(f"Threshold {operator} {threshold_value}: {pct:.1f}% of pixels selected")

    return {**raster, "data": binary[np.newaxis, :, :], "profile": profile, "type": "binary_mask"}


def raster_to_vector(raster: dict, min_area_km2: float = 0.01) -> gpd.GeoDataFrame:
    """
    Convert binary raster mask to vector polygons.

    Args:
        raster: Binary raster dict (values 0 or 1)
        min_area_km2: Minimum polygon area to keep (km²)

    Returns:
        GeoDataFrame of polygons
    """
    from rasterio.features import shapes
    from shapely.geometry import shape

    mask_data = raster["data"][0].astype(np.uint8)
    transform = raster["transform"]
    crs = raster.get("crs", "EPSG:4326")

    geoms = []
    values = []

    for geom, val in shapes(mask_data, transform=transform):
        if val == 1:
            geoms.append(shape(geom))
            values.append(val)

    if not geoms:
        logger.warning("No polygons generated from raster. Returning empty GeoDataFrame.")
        return gpd.GeoDataFrame({"geometry": [], "value": []}, crs=crs)

    gdf = gpd.GeoDataFrame({"geometry": geoms, "value": values}, crs=crs)

    # Filter small polygons
    if min_area_km2 > 0:
        gdf_metric = gdf.to_crs(_get_utm_epsg_from_gdf(gdf))
        areas = gdf_metric.geometry.area / 1_000_000
        gdf = gdf[areas >= min_area_km2].reset_index(drop=True)

    logger.info(f"Raster vectorized: {len(geoms)} → {len(gdf)} polygons (min area: {min_area_km2} km²)")
    return gdf


def save_raster(raster: dict, file_path: str):
    """
    Save raster dict to GeoTIFF file.

    Args:
        raster: Raster dict
        file_path: Output file path
    """
    import rasterio

    Path(file_path).parent.mkdir(parents=True, exist_ok=True)
    profile = raster["profile"].copy()
    profile["count"] = raster["data"].shape[0]

    with rasterio.open(file_path, "w", **profile) as dst:
        dst.write(raster["data"])

    logger.info(f"Raster saved to {file_path}")


# ── Output Operations ─────────────────────────────────────────────────────────

def save_output(
    dataset: Union[gpd.GeoDataFrame, dict],
    file_path: str,
    fmt: str = "geojson",
) -> str:
    """
    Save GIS layer to file.

    Args:
        dataset: GeoDataFrame or raster dict
        file_path: Output file path
        fmt: Format ('geojson', 'shapefile', 'geopackage', 'geotiff')

    Returns:
        Actual file path saved
    """
    Path(file_path).parent.mkdir(parents=True, exist_ok=True)

    if isinstance(dataset, gpd.GeoDataFrame):
        fmt_map = {
            "geojson": ("GeoJSON", ".geojson"),
            "shapefile": ("ESRI Shapefile", ".shp"),
            "geopackage": ("GPKG", ".gpkg"),
        }
        driver, ext = fmt_map.get(fmt, ("GeoJSON", ".geojson"))

        if not file_path.endswith(ext):
            file_path = Path(file_path).with_suffix(ext).__str__()

        dataset.to_file(file_path, driver=driver)
        logger.info(f"Vector saved: {file_path} ({len(dataset)} features, {driver})")

    elif isinstance(dataset, dict) and "data" in dataset:
        save_raster(dataset, file_path)

    return file_path


def get_statistics(gdf: gpd.GeoDataFrame) -> dict:
    """
    Compute summary statistics for a GeoDataFrame.

    Args:
        gdf: Input GeoDataFrame

    Returns:
        Statistics dictionary
    """
    stats = {
        "feature_count": len(gdf),
        "crs": str(gdf.crs) if gdf.crs else None,
        "geometry_types": gdf.geometry.geom_type.value_counts().to_dict(),
        "bounds": list(gdf.total_bounds),
    }

    if "area_km2" in gdf.columns:
        stats["total_area_km2"] = round(gdf["area_km2"].sum(), 4)
        stats["mean_area_km2"] = round(gdf["area_km2"].mean(), 4)
        stats["max_area_km2"] = round(gdf["area_km2"].max(), 4)

    return stats


# ── Helper Functions ──────────────────────────────────────────────────────────

def _get_utm_epsg(lat: float, lon: float) -> str:
    """Get appropriate UTM EPSG code for a given lat/lon."""
    zone = int((lon + 180) / 6) + 1
    if lat >= 0:
        return f"EPSG:{32600 + zone}"
    else:
        return f"EPSG:{32700 + zone}"


def _get_utm_epsg_from_gdf(gdf: gpd.GeoDataFrame) -> str:
    """Get UTM EPSG from GeoDataFrame centroid."""
    gdf_wgs = gdf.to_crs("EPSG:4326")
    centroid = gdf_wgs.unary_union.centroid
    return _get_utm_epsg(centroid.y, centroid.x)


# ── Tool Dispatcher ───────────────────────────────────────────────────────────

TOOL_FUNCTIONS = {
    "load_vector": None,        # Implemented in dataset_loader.py
    "load_raster": None,        # Implemented in dataset_loader.py
    "load_osm": None,           # Implemented in dataset_loader.py
    "buffer": buffer,
    "clip": clip,
    "spatial_join": spatial_join,
    "overlay": overlay,
    "dissolve": dissolve,
    "filter_by_attribute": filter_by_attribute,
    "calculate_slope": calculate_slope,
    "calculate_aspect": calculate_aspect,
    "calculate_ndvi": calculate_ndvi,
    "raster_threshold": raster_threshold,
    "raster_to_vector": raster_to_vector,
    "reproject": reproject,
    "calculate_area": calculate_area,
    "save_output": save_output,
}


def execute_tool(tool_name: str, **kwargs):
    """
    Execute a GIS tool by name.

    Args:
        tool_name: Tool name from registry
        **kwargs: Tool parameters

    Returns:
        Tool output

    Raises:
        ValueError: If tool not found
    """
    if tool_name not in TOOL_FUNCTIONS:
        raise ValueError(f"Unknown tool: {tool_name}. Available: {list(TOOL_FUNCTIONS.keys())}")

    fn = TOOL_FUNCTIONS[tool_name]
    if fn is None:
        raise ValueError(f"Tool '{tool_name}' must be called from dataset_loader module")

    start_time = time.time()
    result = fn(**kwargs)
    elapsed = time.time() - start_time

    logger.info(f"Tool '{tool_name}' completed in {elapsed:.2f}s")
    return result


if __name__ == "__main__":
    # Quick test
    from dataset_loader import generate_synthetic_dem, _generate_synthetic_osm

    # Test raster pipeline
    print("Testing raster pipeline...")
    dem = generate_synthetic_dem()
    slope = calculate_slope(dem)
    print(f"  DEM shape: {dem['data'].shape}, Slope max: {slope['data'].max():.1f}°")

    binary = raster_threshold(dem, "<", 50)
    print(f"  Low elevation pixels: {binary['data'].sum()} / {binary['data'].size}")

    # Test vector operations
    print("\nTesting vector pipeline...")
    rivers = _generate_synthetic_osm("rivers", "Assam")
    print(f"  Rivers: {len(rivers)} features")

    rivers_buffered = buffer(rivers, 500)
    print(f"  After buffer(500m): {len(rivers_buffered)} features")
    print("All tests passed!")
