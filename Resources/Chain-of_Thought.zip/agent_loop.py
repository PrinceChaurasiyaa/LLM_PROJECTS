"""
agent_loop.py
=============
ReAct (Reasoning → Action → Observation) Agent Loop.

Implements the iterative:
  Thought  → Choose the next GIS tool
  Action   → Execute the GIS operation
  Observation → Evaluate results, decide to continue or refine

Includes:
  - Layer registry (in-memory store of intermediate GIS outputs)
  - Execution engine integrating gis_tools and dataset_loader
  - Refinement logic when steps produce unexpected results
  - Full execution logging

Author: GeoSpatial LLM System
"""

import time
import json
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional, Any
from loguru import logger

import geopandas as gpd
import numpy as np


class LayerRegistry:
    """
    In-memory registry for intermediate GIS layer outputs.

    Maps layer names to GeoDataFrames or raster dicts produced
    during workflow execution.
    """

    def __init__(self):
        self._layers: dict[str, Any] = {}
        self._metadata: dict[str, dict] = {}

    def store(self, name: str, data: Any, meta: Optional[dict] = None):
        """Store a layer with optional metadata."""
        self._layers[name] = data
        self._metadata[name] = meta or {}
        self._metadata[name]["stored_at"] = datetime.utcnow().isoformat()

        # Log layer summary
        if isinstance(data, gpd.GeoDataFrame):
            self._metadata[name]["type"] = "vector"
            self._metadata[name]["feature_count"] = len(data)
            self._metadata[name]["crs"] = str(data.crs)
            logger.debug(f"Layer stored: '{name}' | {len(data)} features | CRS: {data.crs}")
        elif isinstance(data, dict) and "data" in data:
            self._metadata[name]["type"] = "raster"
            self._metadata[name]["shape"] = list(data.get("shape", []))
            logger.debug(f"Layer stored: '{name}' | raster {data.get('shape')}")

    def get(self, name: str) -> Optional[Any]:
        """Retrieve a layer by name."""
        return self._layers.get(name)

    def exists(self, name: str) -> bool:
        """Check if a layer exists."""
        return name in self._layers

    def list(self) -> list[str]:
        """List all stored layer names."""
        return list(self._layers.keys())

    def get_metadata(self, name: str) -> dict:
        """Get layer metadata."""
        return self._metadata.get(name, {})

    def summary(self) -> dict:
        """Get summary of all stored layers."""
        return {
            name: meta for name, meta in self._metadata.items()
        }


class AgentLoop:
    """
    ReAct Agent Loop for geospatial workflow execution.

    Iterates through workflow steps, executing each GIS operation
    and observing results to decide next actions.

    Pattern: Thought → Action → Observation → (repeat or complete)
    """

    def __init__(
        self,
        output_dir: str = "outputs",
        max_retries: int = 2,
        save_intermediate: bool = False,
    ):
        """
        Initialize agent loop.

        Args:
            output_dir: Directory for output files
            max_retries: Max retries per step on failure
            save_intermediate: Whether to save intermediate layers to disk
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.max_retries = max_retries
        self.save_intermediate = save_intermediate

        self.registry = LayerRegistry()
        self.execution_log: list[dict] = []
        self.reasoning_log: list[str] = []

        logger.info(f"AgentLoop initialized | output_dir={output_dir}")

    def _thought(self, step: dict, context: dict) -> str:
        """
        Generate a thought about what to do next.

        Args:
            step: Current workflow step
            context: Execution context

        Returns:
            Thought string
        """
        thought = (
            f"Executing Step {step['step_id']}: {step['name']}\n"
            f"  Tool: {step['tool']}\n"
            f"  Goal: {step.get('description', '')}\n"
            f"  Reasoning: {step.get('reasoning', '')}\n"
            f"  Available layers: {self.registry.list()}"
        )
        self.reasoning_log.append(f"[THOUGHT] {thought}")
        logger.info(f"THOUGHT: Step {step['step_id']} - {step['name']} ({step['tool']})")
        return thought

    def _action(self, step: dict) -> Any:
        """
        Execute the GIS action for a step.

        Resolves input references to actual layer data from registry,
        then calls the appropriate GIS function.

        Args:
            step: Workflow step to execute

        Returns:
            Output of the GIS operation
        """
        tool = step["tool"]
        raw_inputs = step.get("inputs", {})

        # Resolve layer references in inputs
        resolved_inputs = self._resolve_inputs(raw_inputs)

        action_log = f"[ACTION] Tool={tool} | Inputs={list(resolved_inputs.keys())}"
        self.reasoning_log.append(action_log)
        logger.info(f"ACTION: Executing '{tool}'")

        result = self._dispatch_tool(tool, step, resolved_inputs)
        return result

    def _observation(self, step: dict, result: Any) -> str:
        """
        Observe and evaluate the result of an action.

        Args:
            step: The executed step
            result: The execution result

        Returns:
            Observation string
        """
        obs_parts = []

        if isinstance(result, gpd.GeoDataFrame):
            obs = (
                f"Vector result: {len(result)} features | "
                f"CRS: {result.crs} | "
                f"Geometry types: {result.geometry.geom_type.value_counts().to_dict()}"
            )
            obs_parts.append(obs)

            if len(result) == 0:
                obs_parts.append("⚠️ WARNING: Empty result — no features found matching criteria")

        elif isinstance(result, dict) and "data" in result:
            data = result["data"]
            obs = (
                f"Raster result: shape={data.shape} | "
                f"dtype={data.dtype} | "
                f"range=[{data.min():.2f}, {data.max():.2f}]"
            )
            obs_parts.append(obs)

            if result.get("type") == "binary_mask":
                pct = (data == 1).sum() / data.size * 100
                obs_parts.append(f"Binary mask: {pct:.1f}% pixels selected")
        else:
            obs_parts.append(f"Result: {type(result).__name__}")

        observation = " | ".join(obs_parts)
        self.reasoning_log.append(f"[OBSERVATION] {observation}")
        logger.info(f"OBSERVATION: {observation}")
        return observation

    def _resolve_inputs(self, raw_inputs: dict) -> dict:
        """
        Resolve string layer references to actual data objects.

        If an input value matches a layer name in the registry,
        replace it with the actual data.

        Args:
            raw_inputs: Raw input dictionary from step spec

        Returns:
            Resolved input dictionary with actual data
        """
        resolved = {}
        for key, val in raw_inputs.items():
            if isinstance(val, str) and self.registry.exists(val):
                resolved[key] = self.registry.get(val)
                logger.debug(f"Resolved input '{key}' → layer '{val}'")
            else:
                resolved[key] = val
        return resolved

    def _dispatch_tool(self, tool: str, step: dict, inputs: dict) -> Any:
        """
        Dispatch to the correct GIS function based on tool name.

        Args:
            tool: Tool name
            step: Full step specification
            inputs: Resolved input data

        Returns:
            Tool execution result
        """
        from dataset_loader import (
            load_raster, load_vector, load_osm,
            generate_synthetic_dem, _generate_synthetic_osm
        )
        from gis_tools import (
            buffer, clip, spatial_join, overlay, dissolve,
            filter_by_attribute, calculate_slope, calculate_aspect,
            calculate_ndvi, raster_threshold, raster_to_vector,
            reproject, calculate_area, save_output
        )

        # ── Data Loading ──
        if tool == "load_raster":
            source = inputs.get("source", inputs.get("file_path", ""))
            if source == "srtm_dem" or not source or source.endswith("_dem"):
                return generate_synthetic_dem()
            return load_raster(source)

        elif tool == "load_vector":
            path = inputs.get("file_path", inputs.get("source", ""))
            return load_vector(path)

        elif tool == "load_osm":
            place = inputs.get("place_name", "Assam, India")
            feat = inputs.get("feature_type", "waterways")
            return load_osm(place, feat)

        # ── Vector Operations ──
        elif tool == "buffer":
            geom = inputs.get("geometry")
            dist = float(inputs.get("distance_meters", inputs.get("distance", 500)))
            if geom is None:
                raise ValueError("buffer requires 'geometry' input")
            return buffer(geom, dist)

        elif tool == "clip":
            target = inputs.get("target_geodataframe", inputs.get("target"))
            mask = inputs.get("mask_geodataframe", inputs.get("mask"))
            if target is None or mask is None:
                raise ValueError("clip requires 'target_geodataframe' and 'mask_geodataframe'")
            return clip(target, mask)

        elif tool == "spatial_join":
            left = inputs.get("left_geodataframe", inputs.get("left"))
            right = inputs.get("right_geodataframe", inputs.get("right"))
            how = inputs.get("how", "left")
            pred = inputs.get("predicate", "intersects")
            if left is None or right is None:
                raise ValueError("spatial_join requires left and right geodataframes")
            return spatial_join(left, right, how=how, predicate=pred)

        elif tool == "overlay":
            gdf1 = inputs.get("geodataframe1", inputs.get("gdf1"))
            gdf2 = inputs.get("geodataframe2", inputs.get("gdf2"))
            how = inputs.get("how", "intersection")
            if gdf1 is None or gdf2 is None:
                raise ValueError("overlay requires 'geodataframe1' and 'geodataframe2'")
            return overlay(gdf1, gdf2, how=how)

        elif tool == "dissolve":
            gdf = inputs.get("geodataframe", inputs.get("gdf"))
            by = inputs.get("by_column", inputs.get("by", "value"))
            return dissolve(gdf, by)

        elif tool == "filter_by_attribute":
            gdf = inputs.get("geodataframe", inputs.get("gdf"))
            col = inputs.get("column")
            op = inputs.get("operator", "==")
            val = inputs.get("value")
            return filter_by_attribute(gdf, col, op, val)

        elif tool == "calculate_area":
            gdf = inputs.get("geodataframe", inputs.get("gdf"))
            return calculate_area(gdf)

        # ── Raster Operations ──
        elif tool == "calculate_slope":
            raster = inputs.get("dem_raster", inputs.get("raster"))
            return calculate_slope(raster)

        elif tool == "calculate_aspect":
            raster = inputs.get("dem_raster", inputs.get("raster"))
            return calculate_aspect(raster)

        elif tool == "calculate_ndvi":
            nir = inputs.get("nir_band", inputs.get("nir"))
            red = inputs.get("red_band", inputs.get("red"))
            return calculate_ndvi(nir, red)

        elif tool == "raster_threshold":
            raster = inputs.get("raster")
            op = inputs.get("operator", "<")
            val = float(inputs.get("threshold_value", 50))
            return raster_threshold(raster, op, val)

        elif tool == "raster_to_vector":
            raster = inputs.get("binary_raster", inputs.get("raster"))
            return raster_to_vector(raster)

        # ── CRS Operations ──
        elif tool == "reproject":
            dataset = inputs.get("dataset")
            target = inputs.get("target_crs", "EPSG:4326")
            return reproject(dataset, target)

        # ── Output ──
        elif tool == "save_output":
            dataset = inputs.get("dataset")
            path = inputs.get("file_path", f"outputs/{step.get('output_layer', 'output')}.geojson")
            fmt = inputs.get("format", "geojson")
            return save_output(dataset, path, fmt)

        elif tool == "generate_map":
            # Map generation handled by visualization module
            layers = inputs.get("layers_list", [])
            return {"type": "map_request", "layers": layers}

        else:
            raise ValueError(f"Unknown tool: {tool}")

    def execute_workflow(
        self,
        workflow: dict,
        progress_callback=None,
    ) -> dict:
        """
        Execute a complete workflow using the ReAct loop.

        For each step:
          1. THOUGHT: Plan the action
          2. ACTION: Execute the GIS tool
          3. OBSERVATION: Evaluate result and decide next action

        Args:
            workflow: Workflow dictionary from WorkflowGenerator
            progress_callback: Optional callable(step_id, message) for UI updates

        Returns:
            Updated workflow dictionary with execution results
        """
        workflow["status"] = "running"
        workflow["started_at"] = datetime.utcnow().isoformat()

        steps = workflow.get("steps", [])
        total_steps = len(steps)

        logger.info(f"Starting workflow execution: {workflow.get('workflow_id')} ({total_steps} steps)")
        self.reasoning_log.append(
            f"[START] Workflow: {workflow.get('workflow_id')} | {total_steps} steps | "
            f"Study area: {workflow.get('study_area')}"
        )

        completed = 0
        failed = 0

        for idx, step in enumerate(steps):
            step_id = step.get("step_id", idx + 1)
            step_name = step.get("name", f"Step {step_id}")

            if progress_callback:
                try:
                    progress_callback(step_id, f"⚙️ {step_name} ({step['tool']})")
                except Exception:
                    pass

            # THOUGHT
            self._thought(step, {"completed_steps": completed})

            # ACTION with retry
            step["status"] = "running"
            step["started_at"] = datetime.utcnow().isoformat()
            result = None
            last_error = None

            for attempt in range(self.max_retries + 1):
                try:
                    result = self._action(step)
                    break  # Success
                except Exception as e:
                    last_error = str(e)
                    if attempt < self.max_retries:
                        logger.warning(f"Step {step_id} attempt {attempt+1} failed: {e}. Retrying...")
                        time.sleep(0.5)
                    else:
                        logger.error(f"Step {step_id} failed after {self.max_retries+1} attempts: {e}")

            if result is not None:
                # OBSERVATION
                observation = self._observation(step, result)

                # Store result in registry
                output_layer = step.get("output_layer", f"layer_{step_id}")
                self.registry.store(output_layer, result, {
                    "step_id": step_id,
                    "tool": step["tool"],
                    "observation": observation,
                })

                # Update workflow outputs
                if isinstance(result, gpd.GeoDataFrame):
                    workflow["outputs"][output_layer] = result
                elif isinstance(result, dict) and "data" in result:
                    workflow["outputs"][output_layer] = result

                step["status"] = "completed"
                step["output_summary"] = observation
                completed += 1

                # Log execution
                self.execution_log.append({
                    "step_id": step_id,
                    "tool": step["tool"],
                    "status": "completed",
                    "observation": observation,
                    "timestamp": datetime.utcnow().isoformat(),
                })

                if progress_callback:
                    try:
                        progress_callback(step_id, f"✅ {step_name}")
                    except Exception:
                        pass

            else:
                # Step failed
                step["status"] = "error"
                step["error"] = last_error
                failed += 1

                error_msg = f"Step {step_id} ({step_name}) failed: {last_error}"
                self.reasoning_log.append(f"[ERROR] {error_msg}")

                self.execution_log.append({
                    "step_id": step_id,
                    "tool": step["tool"],
                    "status": "error",
                    "error": last_error,
                    "timestamp": datetime.utcnow().isoformat(),
                })

                if progress_callback:
                    try:
                        progress_callback(step_id, f"❌ {step_name}: {last_error[:50]}")
                    except Exception:
                        pass

            step["completed_at"] = datetime.utcnow().isoformat()

        # ── Workflow Completion ──
        workflow["completed_at"] = datetime.utcnow().isoformat()
        workflow["status"] = "completed" if failed == 0 else "partial"
        workflow["execution_log"] = self.execution_log
        workflow["reasoning_log"] = self.reasoning_log

        # Compute statistics
        workflow["statistics"] = {
            "total_steps": total_steps,
            "completed": completed,
            "failed": failed,
            "layers_produced": self.registry.list(),
            "layer_summary": self.registry.summary(),
        }

        logger.info(
            f"Workflow complete: {completed}/{total_steps} steps succeeded, "
            f"{failed} failed | Layers: {self.registry.list()}"
        )

        self.reasoning_log.append(
            f"[COMPLETE] {completed}/{total_steps} steps completed. "
            f"Layers available: {self.registry.list()}"
        )

        return workflow

    def get_final_outputs(self) -> dict[str, gpd.GeoDataFrame]:
        """
        Get all vector layer outputs from the registry.

        Returns:
            Dictionary of {layer_name: GeoDataFrame}
        """
        result = {}
        for name in self.registry.list():
            data = self.registry.get(name)
            if isinstance(data, gpd.GeoDataFrame):
                result[name] = data
        return result

    def get_raster_outputs(self) -> dict[str, dict]:
        """
        Get all raster layer outputs from the registry.

        Returns:
            Dictionary of {layer_name: raster_dict}
        """
        result = {}
        for name in self.registry.list():
            data = self.registry.get(name)
            if isinstance(data, dict) and "data" in data:
                result[name] = data
        return result

    def get_reasoning_text(self) -> str:
        """Get formatted reasoning log for display."""
        return "\n".join(self.reasoning_log)

    def reset(self):
        """Reset the agent loop for a new workflow."""
        self.registry = LayerRegistry()
        self.execution_log = []
        self.reasoning_log = []
        logger.info("AgentLoop reset")


if __name__ == "__main__":
    # Test the agent loop
    from workflow_generator import WorkflowGenerator

    gen = WorkflowGenerator("tool_registry.json")
    agent = AgentLoop(output_dir="outputs")

    # Test flood workflow
    llm_output = {
        "workflow_id": "test_flood",
        "study_area": "Assam, India",
        "estimated_crs": "EPSG:32646",
        "steps": [
            {"step_id": 1, "name": "Load DEM", "tool": "load_raster",
             "inputs": {"source": "srtm_dem"}, "output_layer": "dem_raw", "reasoning": "Load elevation"},
            {"step_id": 2, "name": "Threshold Elevation", "tool": "raster_threshold",
             "inputs": {"raster": "dem_raw", "operator": "<", "threshold_value": 50},
             "output_layer": "low_elev", "reasoning": "Find low areas"},
            {"step_id": 3, "name": "Vectorize", "tool": "raster_to_vector",
             "inputs": {"binary_raster": "low_elev"}, "output_layer": "low_elev_zones",
             "reasoning": "Convert to vector"},
            {"step_id": 4, "name": "Load Rivers", "tool": "load_osm",
             "inputs": {"place_name": "Assam, India", "feature_type": "rivers"},
             "output_layer": "rivers", "reasoning": "Load river network"},
            {"step_id": 5, "name": "Buffer Rivers", "tool": "buffer",
             "inputs": {"geometry": "rivers", "distance_meters": 1000},
             "output_layer": "river_buffer", "reasoning": "Buffer around rivers"},
        ]
    }

    workflow = gen.from_llm_output(llm_output, "Flood risk in Assam")

    def progress_cb(step_id, msg):
        print(f"  [{step_id}] {msg}")

    result = agent.execute_workflow(workflow, progress_callback=progress_cb)
    print(f"\nExecution complete: {result['statistics']}")
    print(f"Layers: {agent.registry.list()}")
